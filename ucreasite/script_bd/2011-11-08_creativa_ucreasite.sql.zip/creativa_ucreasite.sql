-- phpMyAdmin SQL Dump
-- version 3.3.7
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 08-11-2011 a las 10:50:45
-- Versión del servidor: 5.0.91
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `creativa_ucreasite`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_areas`
--

CREATE TABLE IF NOT EXISTS `tbl_areas` (
  `area_id` int(11) NOT NULL auto_increment,
  `area_name` varchar(128) NOT NULL,
  `area_description` varchar(256) NOT NULL,
  `area_status` varchar(1) NOT NULL default 'A',
  `area_created` date NOT NULL,
  `area_modified` date NOT NULL,
  PRIMARY KEY  (`area_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `tbl_areas`
--

INSERT INTO `tbl_areas` (`area_id`, `area_name`, `area_description`, `area_status`, `area_created`, `area_modified`) VALUES
(1, 'Área Arquitectónica', 'Área Arquitectónica', 'A', '2011-08-03', '2011-08-03'),
(2, 'Área de Modas', 'Área de Modas', 'A', '2011-08-03', '2011-08-03'),
(3, 'Área Gráfica', 'Área Gráfica', 'A', '2011-08-03', '2011-08-03'),
(4, 'Cursos Libres', 'Cursos Libres', 'A', '2011-08-09', '2011-08-09'),
(5, 'Comunicación', 'área de comunicación', 'A', '2011-10-27', '2011-10-27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_careers`
--

CREATE TABLE IF NOT EXISTS `tbl_careers` (
  `career_id` int(11) NOT NULL auto_increment,
  `area_fk` int(11) NOT NULL,
  `career_name` varchar(128) NOT NULL,
  `career_description` varchar(256) NOT NULL,
  `career_text` text NOT NULL,
  `career_status` varchar(1) NOT NULL default 'A',
  `career_created` date NOT NULL,
  `career_modified` date NOT NULL,
  PRIMARY KEY  (`career_id`),
  KEY `area_fk` (`area_fk`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Volcar la base de datos para la tabla `tbl_careers`
--

INSERT INTO `tbl_careers` (`career_id`, `area_fk`, `career_name`, `career_description`, `career_text`, `career_status`, `career_created`, `career_modified`) VALUES
(1, 1, 'Arquitectura', 'El programa de estudios de la Escuela de Arquitectura prepara los estudiantes para ser profesionales líderes en la práctica de su campo', '[[Descripción]]\r\n<p align="center"><b> “La arquitectura es el arte de organizar el espacio”<br/>\r\nAuguste Perret</b><br/><br/></p>\r\n\r\n<p>La Arquitectura, como carrera o como profesión, es un hecho complejo. Quienes se insertan en su ámbito inician un viaje hacia el conocimiento, un largo periplo lleno de logros y alegrías, de fracasos y tristezas, de reconocimientos y olvidos. <br/><br/>\r\nLa carrera de Arquitectura de la Universidad Creativa se presenta como una opción para el repensar el aprendizaje de esta profesión, al tenor de tres énfasis ideológicos: la arquitectura solidaria, la arquitectura alternativa y la arquitectura apropiada, unificadas bajo una sola idea de Arquitectura. <br/><br/>\r\nEsta visión implica que las y los estudiantes deben involucrarse con la diversidad cultural, económica, social y geográfica del entorno real en el que se desarrollarán luego como profesionales. La Arquitectura es una carrera para soñar y despertarse renovado en el conocimiento, pero también es una actividad de múltiples responsabilidades y grandes exigencias.</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<p>Habilidades mínimas en dibujo a mano alzada, capacidad de construcción de objetos tridimensionales a partir de materiales como, cartón, papel, balsa, etc.</p>\r\n\r\n[[Perfil de salida]]\r\n<p>El programa de estudios de la Escuela de Arquitectura prepara los estudiantes para ser profesionales líderes en la práctica de su campo; el estudio de la arquitectura es un proyecto dedicado a la sustentación de lo imaginado y la necesidad de poder materializarlo dentro del contexto social y ético en que se propone.  La secuencia de diseños ofrece un conocimiento que integra el pensamiento crítico, el diseño, la tecnología, la construcción, la representación así como la responsabilidad social. <br/><br/>\r\nComprometidos fuertemente con las nuevas prácticas nuestros programas constantemente están integrando tecnologías en el currículo de manera que los estudiantes puedan aspirar a una gran independencia tanto en la creatividad como en la parte intelectual por medio del compromiso con una seria investigación inspirada en la arquitectura.</p>\r\n\r\n[[Recursos Tecnológicos]] \r\n<p>En la carrera de arquitectura se necesita tener una mesa de dibujo que permita al estudiante trabajar cómodamente y con buena luz en sus dibujos y maquetas, también es necesario tener una computadora que tenga la capacidad para trabajar con programas como Sketchup, Vector, Autocad, Adobe Photo shop y Adobe Illustrator. </p>\r\n\r\n[[Opciones de Seminarios]]\r\nAnimación Bidimensional I <br/>\r\nVector Works <br/>\r\nAutoCad I <br/>\r\nEstéticas del Siglo XXI <br/>\r\nEconomía,Contabilidad y Presupuestos   <br/>\r\nIluminación <br/>\r\nAutoCad II <br/>\r\nLegislación Urbanística y Constructiva   <br/>\r\n[[Cursos afines]]\r\nIntroducción a la Fotografía Digital <br/>\r\nHistoria del Mueble <br/>\r\nDiseño del Mueble<br/>\r\nCreatividad y Psicoanálisis II <br/>\r\nTécnicas de Presentación II <br/>\r\nApreciación del Arte <br/>\r\nHistoria del Arte III <br/>\r\nManipulación de la Imagen I <br/>\r\nManipulación de la Imagen II <br/>\r\nDiseño Vectorial I <br/>\r\nDiseño Vectorial II <br/>\r\nAnimación Bidimensional I <br/>\r\nVector Works <br/>\r\nAutoCad I <br/>\r\nEstéticas del Siglo XXI <br/>\r\nEconomía, Contabilidad y Presupuestos <br/>\r\nIluminación <br/>\r\nAutoCad II <br/>\r\nLegislación Laboral <br/>\r\nLegislación Urbanística y Constructiva <br/>\r\nSketchup <br/>\r\n<p>Adobe Premiere <br/>\r\nDesarrollo de Gráficos en 3D <br/>\r\nTaller Experimental de Arquitectura <br/>\r\nSeminario Merchandising <br/>\r\nModelado de Información para la Construcción I <br/>\r\nModelado de Información para la Construcción II </p>\r\n\r\n [[Requisitos para bachillerato y licenciatura]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n<li>Título de Bachiller (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(3, 1, 'Decoración del Espacio Interno y Diseño Interno', 'Nuestro interés en el medio ambiente y la preocupación por la educación de nuestros estudiantes, con la conciencia de la búsqueda de nuevas fuentes de producción a todo nivel', '[[Descripción]]\r\n<p align="center"><b> "La arquitectura es la voluntad de la época traducida a espacio" <br/>\r\nMies Van der Rohe</b><br/><br/></p>\r\n\r\n<p>La imaginación y aspiraciones del ser humano están constantemente re haciendo el mundo, transformando los materiales y la energía, fluyendo del planeta hacia los objetos, espacios y lugares de la vida cotidiana. <br/><br/>\r\nEl reto de nuestro tiempo y sobre todo el de nuestra Universidad es que el diseñador se enfoque fundamentalmente en cómo son las cosas, creando objetos bellos y útiles; de impacto inmediato pero de implicaciones a largo plazo.  <br/><br/>\r\nNuestro interés en el medio ambiente y la preocupación por la educación de nuestros estudiantes, con la conciencia de la búsqueda de nuevas fuentes de producción a todo nivel, hacen que juntos estemos abriendo una nueva visión de mundo en la utilización de materiales para el diseño interno y la decoración.</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<p>Habilidades mínimas en dibujo a mano alzada, capacidad de construcción de objetos tridimensionales a partir de materiales como, cartón, papel, balsa, etc.</p>\r\n\r\n[[Perfil de salida]]\r\n<p>Profesionales del Diseño Interior con capacidad para:<br/><br/>\r\n<ul>\r\n<li>Investigar y analizar la disposición y descripción detallada del producto.</li> \r\n<li>Desarrollar la documentación del contrato para facilitar la tasación, consecución e instalación de los muebles.</li> \r\n<li>Proporcionar los servicios de gerencia de proyecto, incluyendo la preparación de los presupuestos y de los horarios de proyecto.</li> \r\n<li>Elaborar los documentos de construcción que consisten en los planos, elevaciones, detalles y las especificaciones para ilustrar los varios elementos del concepto de diseño, incluyendo las disposiciones y localizaciones del tendido de energía y comunicaciones y las localizaciones no-estructurales o no-sísmicas, del techo, diseño de iluminación, la disposiciones de los muebles y los materiales.</li> \r\n<li>Elaborar los documentos de construcción que adhieren a los códigos regionales sobre materiales, los códigos municipales y cualesquiera otros estatutos, regulaciones y pautas jurisdiccionales que se apliquen al espacio interior.</li> \r\n<li>Coordinar y colaborar con los profesionales aliados al diseño incluyendo quienes proporcionan los servicios adicionales para el proyecto de diseño, pero no limitado a los arquitectos, los ingenieros estructurales, los ingenieros industriales y los ingenieros eléctricos, además de varios consultores especializados involucrados en el proyecto de diseño.</li>\r\n<li>Administrar como agente los documentos, las ofertas y las negociaciones del contrato con el cliente.</li> \r\n<li>Observar y divulgar la información sobre el progreso y la terminación del proyecto del diseño, además de conducir la evaluación de la post-ocupación y de preparar informes de la post-ocupación a nombre del cliente.</li></ul><br/><br/> \r\nEl Perfil de Salida de los estudiantes graduados de la Escuela de Decoración son profesionales en el campo que tienen la capacidad de afrontar proyectos de cualquier envergadura en el campo, con criterio específico para defenderse en toda la gama de tipos de proyectos de Decoración desde comerciales hasta residenciales.  Profesionales con bases sólidas en cuanto a composición, color y proporción capaces de trabajar en su propia empresa o incorporarse a cualquiera ya existente.</p> \r\n\r\n[[Recursos Tecnológicos]] \r\n<p>En la carrera de Diseño Interior se necesita tener una mesa de dibujo que permita al estudiante trabajar cómodamente y con buena luz en sus dibujos y maquetas, también es necesario tener una computadora que tenga la capacidad para trabajar con programas como Sketchup, Vector, Autocad, Adobe Photoshop y Adobe Illustrator. </p><br/><br/>\r\n\r\n\r\n[[Opciones de Seminarios]]\r\nEscaparatismo<br/>\r\nEscenografía<br/>\r\nAutoCad I<br/>\r\nAutoCad II<br/>\r\nVector Works<br/>\r\nSketchup<br/>\r\nAdobe Premiere<br/>\r\nIntroducción a la Arquitectura<br/>\r\n\r\n[[Cursos afines]]\r\nEscaparatismo<br/>\r\nEscenografía<br/>\r\nHistoria de la Ciudad<br/>\r\nManipulación de la Imagen I<br/>\r\nManipulación de la Imagen II<br/>\r\nAutoCad I <br/>\r\nAutoCad II<br/>\r\nVector Works <br/>\r\nEcología y Diseño<br/>\r\nDiseño para el III Milenio<br/>\r\nSeminario de Psicología del Color<br/>\r\nSketchup<br/>\r\nAdobe Premiere<br/>\r\nSeminario Merchandizing<br/>\r\nComunicación y Sociedad<br/>\r\nIntroducción a la Arquitectura<br/> \r\n\r\n[[Requisitos para técnico Decoración del espacio Interno]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n[[Requisitos para bachillerato y licenciatura]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n<li>Título de Bachiller (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(4, 1, 'Dibujo Arquitectónico', 'se debe resolver de manera óptima el dibujo arquitectónico y sus aplicaciones, para poder aprovechar al máximo sus posibilidades', '[[Descripción]]\r\n<p align="center"><b> “Dibujar es planear, organizar, ordenar, relacionar y controlar” <br/>\r\nJoseph Albers</b><br/><br/></p>\r\n\r\n<p>Al enfrentarnos al diseño de infraestructura, se debe resolver de manera óptima el dibujo arquitectónico y sus aplicaciones, para poder aprovechar al máximo sus posibilidades. Puesto que la arquitectura proyecta los espacios que habita el hombre se debe comprender y tomar en cuenta las proporciones regulares de la figura humana.  <br/><br/>\r\nNuestro interés en el medio ambiente y la preocupación por la educación de nuestros estudiantes, con la conciencia de la búsqueda de nuevas fuentes de producción a todo nivel, hacen que juntos estemos abriendo una nueva visión de mundo en la utilización de materiales para el diseño interno y la decoración.<br/<br/>\r\nEsta clase de dibujo sirve para ilustrar los diferentes elementos de los proyectos y la forma que adoptarán una vez finalizados. Las distintas representaciones gráficas abarcan la perspectiva, las proyecciones ortogonales, el croquis, los diseños por computadora, planos y representaciones 3D.<br/><br/>\r\nEl profesional que se desempeñe en dibujo arquitectónico será capaz de diseñar espacios de manera adecuada, tomando en cuenta todas las vertientes que se le pueden presentar.</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<p>Habilidades mínimas para el manejo de los programas de cómputo para el dibujo arquitectónico.</p>\r\n\r\n[[Perfil de salida]]\r\n<p>El programa de estudios de la Escuela de Arquitectura prepara los estudiantes para ser profesionales líderes en la práctica de su campo; el estudio del dibujo arquitectónico es un proyecto dedicado a la sustentación de lo imaginado y la necesidad de poder materializarlo dentro del contexto social y ético en que se propone.  La secuencia de diseños ofrece un conocimiento que integra el pensamiento crítico, el diseño, la tecnología, la construcción, la representación así como la responsabilidad social.<br/><br/>\r\nComprometidos fuertemente con las nuevas prácticas nuestros programas constantemente están integrando tecnologías en el currículo de manera que los estudiantes puedan aspirar a una gran independencia tanto en la creatividad como en la parte intelectual por medio del compromiso con una seria investigación inspirada en la arquitectura.\r\n</p> \r\n\r\n[[Recursos Tecnológicos]] \r\n<p>En la carrera de dibujo arquitectónica se necesita tener una mesa de dibujo que permita al estudiante trabajar cómodamente y con buena luz en sus dibujos y maquetas, también es necesario tener una computadora que tenga la capacidad para trabajar con programas como Sketchup, Vector, Autocad, Adobe Photoshop y Adobe Illustrator.</p><br/><br/>\r\n\r\n\r\n[[Opciones de Seminarios]]\r\n<p>Seminario de Diseño de Portafolio</p>\r\n\r\n\r\n[[Cursos afines]]\r\nIntroducción a la Fotografía Digital<br/> \r\nHistoria del Mueble <br/> \r\nDiseño del Mueble<br/> \r\nCreatividad y Psicoanálisis II<br/>  \r\nTécnicas de Presentación II <br/> \r\nApreciación del Arte <br/> \r\nHistoria del Arte III <br/> \r\nManipulación de la Imagen I <br/> \r\nManipulación de la Imagen II <br/> \r\nDiseño Vectorial I <br/> \r\nDiseño Vectorial II <br/> \r\nAnimación Bidimensional I <br/> \r\nVector Works <br/> \r\nAutoCad I <br/> \r\nEstéticas del Siglo XXI<br/>  \r\nEconomía, Contabilidad y Presupuestos <br/> \r\nIluminación <br/> \r\nAutoCad II <br/> \r\nLegislación Laboral<br/>  \r\nLegislación Urbanística y Constructiva<br/>  \r\nSketchup <br/> \r\nAdobe Premiere <br/> \r\nDesarrollo de Gráficos en 3D<br/>  \r\nTaller Experimental de Arquitectura<br/>  \r\nSeminario Merchandising<br/>  \r\nModelado de Información para la Construcción I <br/> \r\nModelado de Información para la Construcción II <br/> \r\n\r\n[[Requisitos para técnico]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(6, 2, 'Diseño de Modas', 'La carrera de Diseño de Modas tiene como objetivo principal preparar diseñadores que sean capaces de resolver colecciones de indumentaria tanto femenina como masculina', '[[Descripción]]\r\n<p align="center"><b> "Las mujeres no llevan lo que les gusta. Les gusta lo que llevan" <br/>\r\nChristian Dior</b><br/><br/></p>\r\n\r\n<p>La carrera de Diseño de Modas tiene como objetivo principal preparar diseñadores que sean capaces de resolver colecciones de indumentaria tanto femenina como masculina, combinando la rigurosidad técnica, sin olvidar jamás la esencia estética que define a un diseño de calidad y que satisface de forma innovadora las necesidades del consumidor inteligente.  <br/><br/>\r\nDiseño de Modas les ofrece la posibilidad de insertarse en el mercado laboral nacional o internacional ya sea en micro, pequeñas medianas o grandes empresas que se dediquen a la elaboración de productos de moda, siendo esta industria la tercera más grande a nivel mundial en generación de empleos directos o indirectos y en beneficios económicos, esto nos muestra las grandes oportunidades  de una de las industrias más solidas  y adaptables en épocas de cambio.</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n\r\n<ul>\r\n<li>Ser una persona creativa, crítica y sensible al arte y al diseño. </li>\r\n<li>Ser proactivo y dispuesto a trabajar por objetivos. </li>\r\n<li>Tener habilidad para trabajos manuales o que involucren la construcción de objetos en dos o tres dimensiones. </li>\r\n<li>Tener habilidad para el dibujo artístico y técnico.</li></ul>\r\n\r\n[[Perfil de salida]]\r\n<p>Las personas con el grado de Diplomado en Diseño de Modas de la Universidad Creativa, pueden desempeñarse, entre otras, en las siguientes ocupaciones: <br/><br/>\r\n<ul>\r\n<li>Gerente, sub-gerente, director general o jefe de departamento de Diseño en empresas relacionadas con la industria textil y el Diseño de Modas. </li>\r\n<li>Administrador de su propia empresa. </li>\r\n<li>Creativos en empresas especializados en eventos, promocionales y presentaciones públicas. </li>\r\n<li>Asesor independiente en Diseño de Modas. </li>\r\n<li>Investigador de mercados de la Moda. </li>\r\n<li>Diseñador de modas en empresas de industria textil. </li>\r\n<li>Programador de la producción en empresas de industria textil. </li>\r\n<li>Diseñador de nuevos procedimientos, técnicas de diseño y confección. </li>\r\n<li>Diseñador para textiles. </li>\r\n<li>Docente de la Carrera de Diseño de Modas y la Industria Textil en Colegios, Institutos y Universidades. </li>\r\n<li>Integrante de grupos interdisciplinarios de trabajo. </li>\r\n<li>Asesor de actividades artísticas y proyectos culturales. </li>\r\n<li>Consultor de modas en prensa, televisión y radio. </li>\r\n</ul>\r\n\r\n[[Recursos Tecnológicos]]\r\n\r\n<p>En la carrera de diseño de modas se necesita tener una máquina de coser preferiblemente semi industrial (puede tener una casera) también es necesario tener una computadora que tenga la capacidad para trabajar con programas como Adobe Photoshop y Adobe Illustrator.</p>\r\n \r\n[[Opciones de Seminarios]]\r\nTécnicas de Investigación<br/>\r\nManipulación de la Imagen I<br/>\r\nSeminario de Trajes de Baño <br/>\r\nSeminario de Lencería<br/>\r\nVisual Merchandising <br/>\r\nTécnicas de Estampación Textil<br/> \r\nSeminario de Trajes de Noche  <br/>\r\nSeminario de Patronaje Creativo <br/>\r\nDiseño de Portafolio <br/>\r\n\r\n\r\n[[Cursos libres afines]]\r\n\r\nDibujo Analítico <br/>\r\nDbujo Anatómico <br/>\r\nEscaparatismo <br/>\r\nIntroducción a la Foto Digital <br/>\r\nIntroducción al Diseño de Joyería y Accesorios <br/>\r\nTI para la Producción <br/>\r\nSeminario del Color <br/>\r\n\r\n[[Requisitos para diplomado]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n<li>Título de Bachiller (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n[[\r\n', 'A', '2011-08-03', '2011-08-03'),
(7, 2, 'Joyería y Accesorios', 'Los invitamos a vivir técnicas ancestrales no solo de nuestros impresionantes antepasados  sino también de culturas lejanas y poco conocidas', '[[Descripción]]\r\n<p align="center"><b> "El diamante surge de la miseria de un carbón; la misera del joyero se convierte en piedra preciosa, gracias a sus manos y creación"   <br/>\r\nD.Guti</b><br/><br/></p>\r\n\r\n<p>Somos los pioneros no solo dentro de nuestro país Costa Rica, sino también en todo América y en muchos países del mundo, emprendemos el maravilloso camino de la creación a nivel artístico - artesanal de la joyería y de los accesorios- siendo este el augurio sonante en el mundo como movimiento vanguardista en este oficio.   <br/><br/>\r\nLos invitamos a vivir técnicas ancestrales no solo de nuestros impresionantes antepasados  sino también de culturas lejanas y poco conocidas.   Nuestro objetivo principal es que se desenvuelvan dentro de un marco creativo e innovador, desarrollando conceptos y tendencias vanguardistas, teniendo como objetivo específico el diseño de piezas de autor.<br/>,br/>\r\nJoyería y Accesorios ha evolucionado en técnica y conceptualización, teniendo un auge dentro del diseño de modas, que abarca desde la producción de una pieza por su estética hasta verse comprometida con su entorno, cultura, desarrollo tecnológico y funcionalidad.\r\n</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<ul>\r\n<li>Solicitud de ingreso a carrera.</li> \r\n<li>Ser creativo y sensible al arte y al diseño.</li>\r\n<li>Ser proactivo y dispuesto a trabajar por objetivos.</li> \r\n<li>Tener habilidad para trabajos manuales o que involucren la construcción de objetos en dos o tres dimensiones.</li> \r\n<li>Tener habilidad e interés en el dibujo artístico y técnico.</li>\r\n\r\n[[Perfil de salida]]\r\n<p>El diseñador de Joyería y Accesorios, graduado de la Universidad Creativa contará con el conocimiento para competir en un mercado de creciente demanda, saldrá con el dominio de las técnicas del orfebre moderno, concepto y realización de cera perdida, y el manejo de diversas técnicas de fundición y aleación de metales, creación y fusión de diversas técnicas modernas y antiguas. Control de materiales, herramientas y dominio de la historia, la química y la teoría gemológica.</p>\r\n\r\n[[Recursos Tecnológicos]] \r\n<ul>\r\n<li>Espacio de trabajo apto para el trabajo manual, recomendado taller de orfebrería. Dentro de nuestros cursos capacitamos y diseñamos los talleres a la medida, según las técnicas más utilizadas.</li> \r\n<li>Herramientas Básicas y especiales de Orfebrería, dentro de nuestros cursos recomendamos y creamos nuestras herramientas. </li>\r\n<li>Materiales varios de pintura y dibujo.</li> \r\n<li>Computadora para cursos avanzados.</li> \r\n\r\n[[Opciones de Seminarios]]\r\nSeminario de Diseño de Portafolio<br/> \r\nSeminario Fotografía de Producto<br/> \r\nSeminario Joyería en Vitral y Vitro Fusión <br/>\r\nSeminario Photoshop I <br/>\r\nSeminario Illustrador I <br/>\r\nSeminario Sketchup <br/>\r\nSeminario 3D studio I y 3D studio II <br/>\r\nSeminario de Especialización I<br/>\r\n\r\n[[Cursos afines]]\r\nDibujo Anatómico<br/> \r\nIntroducción a la Fotografía Digital<br/>  \r\nHistoria del Vestido I, Historia del Vestido II <br/> \r\nSeminario de Color <br/> \r\nDiseñadores de Modas del Siglo XX <br/> \r\nTeoría de la Imagen <br/> \r\nVitrales I <br/> \r\nVitrales II <br/> \r\nApreciación del Arte<br/> \r\n\r\n\r\n[[Requisitos para técnico]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(8, 2, 'Producción Textil', 'La producción textil es una industria muy competitiva a nivel global, Costa Rica está dirigiendo el bajo volumen de producción como estrategia competitiva', '[[Descripción]]\r\n<p align="center"><b> "Hay una fuerza motriz más poderosa que el vapor, la electricidad y la energía atómica: la voluntad" <br/>\r\nAlbert Einstein</b><br/><br/></p>\r\n\r\n<p>La producción textil es una industria muy competitiva a nivel global, Costa Rica está dirigiendo el bajo volumen de producción como estrategia competitiva, con mano de obra especializada y reconocida a nivel mundial, adicionando a esto un gran nivel de diseño diferenciado en las prendas, gracias a los profesionales de diseño de modas que están forjando un nicho de mercado a nivel nacional.<br/><br/>\r\nLa entrada de diseñadores de modas formados por la Universidad Creativa aprobado por el Ministerio de Educación de Costa Rica en 1995, dejo al descubierto la necesidad de personal capacitado en la industria textil sensible a las necesidades artísticas y el enfoque de tendencias, estudio de mercado para la industria nacional con identidad costarricense que se proyecta a nivel internacional. <br/><br/>\r\nDada la complejidad del manejo de maquila en el país, con respecto a las políticas y capacitación del personal para cumplir con las expectativas del crecimiento del diseño de indumentaria en Costa Rica, se genera la necesidad del mercado laboral, personal enfocado al manejo de la producción textil con concepto y calidad dirigidos a fortalecer la industria nacional.</p>   \r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<ul>\r\n<li>Ser una persona creativa, crítica y sensible al arte y al diseño.</li> \r\n<li>Ser proactivo y dispuesto a trabajar por objetivos.</li> \r\n<li>Tener habilidad para trabajos manuales o que involucren la construcción de objetos en dos o tres dimensiones.</li> \r\n<li>Tener habilidad para el dibujo artístico y técnico.</li>\r\n<li>Tener disposición para la costura y la construcción de patrones. </li> \r\n\r\n\r\n[[Perfil de salida]]\r\n<p>La expansión de las actividades de productos textiles que requieren los mercados internos y externos, el profesional en producción textil podrá insertarse en una creciente variedad de micro, pequeñas y medianas empresas que ya están operando en el país.\r\nLa perspectiva de desarrollo en las funciones de: supervisión, administración de los servicios técnicos y eventual continuidad de preparación a otros niveles del Grupo Creativo. \r\nLos graduados en este grado pueden desempeñarse, en las siguientes ocupaciones:<br/><br/>\r\n<ul>\r\n<li>Administrar su propia producción textil.</li> \r\n<li>Asesor independiente de líneas de producción textil.</li> \r\n<li>Programador de la producción en las empresas de la industria textil.</li>\r\n</p> \r\n\r\n[[Recursos Tecnológicos]] \r\n<p>En la carrera de producción textil se necesita tener un máquina de coser preferiblemente semi industrial, pero se puede tener una casera, también es necesario tener una computadora que tenga la capacidad para trabajar con programas de como Adobe Photoshop y Adobe Illustrator. <br/><br/>\r\nPC,  Mac (Escritorio)<br/>\r\nRequisitos recomendados. <br/>\r\nSistema operativo Windows o Mac OS X<br/>\r\nAl menos 1 gigabyte de RAM.<br/>\r\nMonitor con resolución al menos superior  1024 X 768 pixeles.\r\n</p><br/><br/>\r\n\r\n\r\n[[Opciones de Seminarios]]\r\nSeminario de Trajes de Baño<br/>  \r\nSeminario de Lencería<br/>\r\nTécnicas de Estampación Textil  \r\n\r\n[[Cursos afines]]\r\nDibujo Analítico<br/> \r\nDibujo Anatómico <br/>\r\nEscaparatismo <br/>\r\nIntroducción a la Foto Digital <br/>\r\nIntroducción al Diseño de Joyería y Accesorios <br/>\r\nTI para la Producción <br/>\r\nSeminario del color <br/>\r\n \r\n[[Requisitos de ingreso]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(9, 3, 'Diseño Gráfico', 'Diseño Gráfico es una de las carreras con mayor desarrollo en el mercado en los últimos años debido a la creciente demanda de servicios de comunicación y publicidad', '[[Descripción]]\r\n<p align="center"><b> “El diseño es el método de juntar la forma y el contenido. Es simple, por eso es tan complicado” <br/>\r\nPaul Rand</b><br/><br/></p>\r\n\r\n<p>Diseño Gráfico es una de las carreras con mayor desarrollo en el mercado en los últimos años debido a la creciente demanda de servicios de comunicación y publicidad. Un Diseñador gráfico debe caracterizarse por una amplia cultura general, disposición para actualizarse constantemente y un marcado gusto por lo estético cualquiera que sea su origen. <br/><br/>\r\nLa carrera se caracteriza por la búsqueda de una profunda comprensión del cliente y un exhaustivo análisis de sus necesidades a nivel de comunicación. Dentro de nuestro plan de estudio el área técnica se destaca la cantidad de horas laboratorio y la diversidad de los software utilizados. <br/><br/>\r\nNuestros graduados pueden desempeñarse en áreas muy variadas, desde agencias de publicidad, hasta en lugares que requieren de conocimiento técnico desarrollado tales como imprentas; sin dejar de lado la posibilidad, de conformar una empresa independiente o el trabajo freelance.</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<p>El estudiante de Diseño Gráfico debe caracterizarse por: \r\nGran disposición para trabajar en comunicación visual, es alguien a quien el dibujo, y la representación gráfica le atraen.<br/><br/> \r\nGusto por el arte sin importar cuál es el origen de esta, debe tener un punto de vista abierto a posibilidades y ser receptivo a nuevas herramientas. Sin embargo cabe resaltar que un diseñador NO es un artista, es un Diseñador. <br/><br/>\r\nPreferencia por el trabajo digital y las computadoras, además es alguien que siente interés por la tecnología. \r\nAlguien que no se limite a un tipo de trabajo especifico, el trabajo de los diseñadores cambia y se reconfigura dependiendo de una gran cantidad de factores, desde el cliente y sus necesidades hasta los medios en los que se ha de publicar el trabajo. <br/><br/>\r\nEs una persona que se interesa por todo tipo de información, un Diseñador debe tener una amplia cultura general.<br><br/> \r\nApertura a la crítica y la autocritica, la mejor forma de evolucionar en diseño es aprendiendo a aceptar los comentarios y acotaciones de quienes nos rodean. \r\n</p>\r\n\r\n[[Perfil de salida]]\r\n<p>Las personas con el grado de Bachillerato en Diseño Gráfico de la Universidad Creativa, pueden desempeñarse, entre otras, en las siguientes ocupaciones: <br/><br/>\r\n<ul>\r\n<li>Diseñador gráfico en agencias de publicidad.</li>\r\n<li>Administrador de su propia empresa.</li> \r\n<li>Diseño aplicado a páginas web o interfaces visuales.</li> \r\n<li>Museografía para instituciones varias.</li> \r\n<li>Infografía para publicaciones.</li>\r\n<li>Diagramador en publicaciones.</li> \r\n<li>Arte Finalista.</li>\r\n</p> \r\n\r\n[[Recursos Tecnológicos]] \r\n<p>Una de las herramientas primordiales del Diseñador Gráfico moderno es una computadora, preferiblemente capaz de permitirle al Diseñador ajustarse a los habituales cambios en el software, ya es un hecho comprobado que en promedio cada 2 años hay que actualizar los componentes de un computador para mantenerlo 100% funcional.<br/><br/> \r\nAquí algunas recomendaciones: PC, Mac (Escritorio) <br>\r\nRequisitos recomendados. Sistema operativo Windows 7 64 bits. Sistema operativo Mac OS X, o superior. Al menos 4 gigabyte de RAM. Monitor con resolución al menos superior 1024 X 768 pixeles. Un procesador con no más de 3 años de antigüedad. Disco Duro de al menos 250 Gigas. Tableta Digitalizadora (recomendado) </p>\r\n\r\n[[Opciones de Seminarios]]\r\nConstrucción de páginas web II<br/>\r\nAnimación Bidimensional II <br/>\r\nAnimación Bidimensional III <br/>\r\nModelado Orgánico I <br/>\r\nTécnica Fotográfica I <br/>\r\nApreciación del Arte  <br/>\r\nPublicación Electrónica <br/>\r\nTécnicas de Montaje (Obligatorio)<br/>\r\nDiseño de Portafolio (Obligatorio)<br/>\r\n\r\n[[Cursos afines]]\r\nEdición de Video Digital I<br/>\r\nDibujo Digital I <br/>\r\nManipulación de la imagen para web I <br/>\r\nManipulación de la imagen para web II <br/>\r\nTeoría de la Imagen <br/>\r\nFotografía del Producto <br/>\r\nMorfología y Modelado \r\n\r\n[[Requisitos para bachillerato y licenciatura]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n<li>Título de Bachiller (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(10, 3, 'Animación', 'En un medio siempre cambiante y en simbiosis con la fuerza actual con la que está emergiendo el medio audiovisual en Costa Rica', '[[Descripción]]\r\n<p align="center"><b> "Al infinito, y más allá" <br/>\r\nBuzz Lightyear [de Toy Story]</b><br/><br/></p>\r\n\r\n<p>En un medio siempre cambiante y en simbiosis con la fuerza actual con la que está emergiendo el medio audiovisual en Costa Rica, la Universidad Creativa gesta esta carrera con la intención de apoyar de manera profesional y sistemática este esfuerzo. <br/><br/>\r\nEl planteamiento formativo se basa en el estudio de métodos tradicionales de animación llevados a técnicas contemporáneas como el 3D, el Stop Motion y la animación bidimensional computarizada, ofreciendo así una ramificación amplia de aplicaciones para el desempeño profesional.   <br/><br/>\r\nEstos conocimientos se fundamentan en el campo de la comunicación visual, teniendo así una gran fortaleza en el área de dibujo, manejo de cámaras, actuación y física, de manera tal que los principios de animación y la historia puedan ser presentados de manera cautivante. </p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<p>Para ser estudiante de la carrera el aplicante deberá: <br/><br/>\r\n<ul>\r\n<li>Ser una persona creativa, crítica y sensible al arte y al diseño.</li> \r\n<li>Ser proactivo y dispuesto a trabajar por objetivos.</li> \r\n<li>Tener habilidad para trabajos manuales o que involucren la construcción de objetos en dos o tres dimensiones.</li> \r\n<li>Tener habilidad para el dibujo artístico y técnico.</li> \r\n<li>Dominio muy básico del idioma inglés.</li>\r\n<li>Manejo básico de computador.</li>\r\n\r\n[[Perfil de salida]]\r\n</p>Una vez finalizados sus estudios el egresado como Técnico en Animación de la Universidad Creativa podrá desempeñarse de manera efectiva en puestos de animador en estudios existentes, además podrá ingresar en el mercado de la televisión generando contenido animado en tiempo real, participar en el desarrollo de comerciales televisivos, formar parte de una agencia de publicidad y en general comunicarse apropiadamente con las diferentes escalas y disciplinas del medio audiovisual.</p>\r\n\r\n[[Recursos Tecnológicos]] \r\n<p>Una de las herramientas primordiales de la Animación moderna es una computadora, preferiblemente capaz de permitirle al Animador ajustarse a los habituales cambios en el software, ya es un hecho comprobado que en promedio cada 2 años hay que actualizar los componentes de un computador para mantenerlo 100% funcional. <br/> \r\nAquí algunas recomendaciones: PC,Mac (Escritorio)<br/>\r\nRequisitos recomendados. Sistema operativo Windows 7 64 bits. Sistema operativo Mac OS X, o superior. Al menos 4 gigabyte de RAM. Monitor con resolución al menos superior 1024 X 768 pixeles. Un procesador con no más de 3 años de antigüedad. Disco Duro de al menos 250 Gigas. Tableta Digitalizadora (recomendado) \r\n</p>\r\n\r\n\r\n[[Opciones de Seminarios]]\r\nManipulación de la Imagen I<br/>\r\nDiseño Vectorial I<br/>\r\nPrincipios de sonido<br/>\r\n\r\n[[Cursos afines]]\r\nNarrativa Audiovisual<br/>\r\nPrincipios para Video<br/>\r\nEdición de Video Digital II<br/>\r\nMorfología y Modelado<br/>\r\n\r\n[[Requisitos para técnico]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(11, 3, 'Desarrollo Web', 'El ritmo de vida actual exige rapidez de información; y la Internet es un medio para conseguirla a un bajo costo. ', '[[Descripción]]\r\n<p align="center"><b> "El buen diseño es obvio. El gran diseño es transparente" <br/>\r\nMieke Gerritzen</b><br/><br/></p>\r\n\r\n<p>El ritmo de vida actual exige rapidez de información; y la Internet es un medio para conseguirla a un bajo costo. Este es un mercado competitivo y de grandes exigencias; en donde la tecnología y la actualización de programas juegan un papel muy importante. Acorde con esto es que con laboratorios de última tecnología y profesores calificados es que se busca formar profesionales en la creación de Sitios Web. El objetivo es que los alumnos creen propuestas innovadoras, funcionales y originales.</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<p>Los y las estudiantes de Desarrollo Web deben visualizarse trabajando muchas horas frente a una computadora. Debe gustarle mantenerse informados sobre nuevas tecnologías de la información y la comunicación así como ser personas proactivas y que les guste trabajar por objetivos. </p>\r\n\r\n[[Perfil de salida]]\r\n<p>El diseñador Web puede trabajar para empresas que apuesten por su presencia en la Internet, o para empresas que se dediquen a ofrecer este tipo de servicios, habiendo una amplia demanda de empleo.</p><br/><br/>\r\n\r\n[[Recursos tecnológicos]]\r\nAcceso a una computadora con internet, con los siguientes requisitos mínimos.\r\n Computadoras PC, Mac.<br/>\r\nSistema operativo Windows o Mac OS X, o Linux ( para utilizar Dreamweaver solo funciona Windows o Mac)<br/>\r\nAl menos 1 gigabyte de RAM.\r\nMonitor con resolución al menos superior 1024 X 768 pixeles.\r\n\r\n[[Opciones de Seminarios]]\r\nUn seminario de especialización optativo<br/> \r\nSeminario de Diseño de Portafolio<br/> \r\n\r\n[[Cursos afines]]\r\n<p>Narrativa Audiovisual</p>\r\n\r\n[[Requisitos para técnico]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(12, 3, 'Modelo Digital en 3D', 'Ante la necesidad imperante de técnicos capaces de producir modelos tridimensionales de alta calidad', '[[Descripción]]\r\n<p align="center"><b>“…El modelado digital? Las audiencias están ahora tan acostumbradas,<br/> que no distinguen que es modelado digital y que es real” <br/>\r\nJan de Bont  </b><br/><br/></p>\r\n\r\n<p>Ante la necesidad imperante de técnicos capaces de producir modelos tridimensionales de alta calidad, que puedan utilizarse tanto en el medio ilustrativo como en el audiovisual nace la carrera de Modelado Digital en 3D. <br/><br/>\r\nEste técnico, por medio de la combinación de medios digitales y tradicionales obtiene profesionales íntegros en conocimiento teórico-práctico y con capacidades de transferir su producto a otras escalas de las líneas productivas en las que estarán inmersos. \r\n</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<p>Para ser estudiante de la carrera el aplicante deberá:  <br/><br/>\r\n<ul>\r\n<li>Ser una persona creativa, crítica y apasionada por los mundos virtuales en tres dimensiones.</li> <li>Ser proactivo y dispuesto a trabajar en equipo y por objetivos.</li> <li> Tener habilidad para trabajos manuales o que involucren la construcción de objetos en dos o tres dimensiones.</li>\r\n<li>Tener habilidad para el dibujo artístico y técnico.</li>\r\n</p>\r\n\r\n[[Perfil de salida]]\r\n<p>Al terminar sus estudios, el egresado en Técnico de Modelado Digital en 3D de la Universidad Creativa, le permitirá ingresar laboralmente a medios de comunicación masivos tales como cine, televisión y web. Sus modelos podrán ser útiles para aplicaciones web, ilustraciones, juegos de video, animación y efectos especiales. <br/><br/>\r\nEl profesional podrá comunicarse efectivamente en los ámbitos productivos y dar apoyo creativo en diferentes áreas de los proyectos que realice, tanto como parte de una empresa como de manera independiente. \r\n</p> \r\n\r\n[[Recursos Tecnológicos]] \r\n<p>3ds Max 2012 32-bits o 3ds Max Design 2012 para Windows <br/>\r\nSistema operativo: Microsoft® Windows® 7, Microsoft® Windows Vista® (Service Pack 2 mínimo), or Microsoft® Windows® XP Profesional (Service Pack 3 mínimo). <br/>\r\nA partir del III cuatrimestre: Trípode, Flash externo)<br/>\r\nPara animación general y renderizado (generalmente menos de 1,000 objetos or 100,000 polígonos): <br/>\r\n<ul>\r\n<li>Procesador Intel® Pentium® 4 1.4 GHz o equivalente procesador AMD® con tecnología SSE2</li> <li>2 GB RAM (4 GB recomendado)</li> <li>2 GB espacio de intercambio (4 GB recomendado) <li>3 GB de espacio libre en el disco duro</li> <li> Tecnología Direct3D® 10, Direct3D 9, o OpenGL-capable en la tarjeta de video (256 MB de memoria de video o superior, 1 GB o superior recomendado)</li> <li>Mouse de 3 botones</li> <li>DVD-ROM</li> <li>Microsoft® Internet Explorer® 8.0 o superior o Mozilla® Firefox® 3.0 o superior</li> <li>Conexión a Internet</li></p>\r\n\r\n[[Opciones de Seminarios]]\r\nSeminario de Diseño de Portafolio <br/> \r\nSeminario de Especialización <br/>\r\n\r\n[[Cursos afines]]\r\nTaller de Modelado y Desgaste <br/> Maquetas <br/> Diseño del mueble <br/> \r\n[[Requisitos para técnico]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(13, 3, 'Producción de Medios Digitales', 'La carrera de Producción Audiovisual surge para ofrecer la oportunidad de realización profesional a un sector amplio que demanda un espacio de formación, estimulando la convergencia entre desarrollo de la creatividad y aplicación de las nuevas tecnologías.', '[[Descripción]]\r\n<p align="center"><b>"La fotografía es verdad. Y el cine es verdad 24 veces por segundo"<br/>\r\nJean Luc Godard   </b><br/><br/></p>\r\n\r\n<p>La carrera de Producción Audiovisual surge para ofrecer la oportunidad de realización profesional a un sector amplio que demanda un espacio de formación, estimulando la convergencia entre desarrollo de la creatividad y aplicación de las nuevas tecnologías.\r\n<br/><br/>\r\nLa sociedad actual experimenta cada día una mayor exposición a múltiples formas de comunicación que exigen de técnicos y profesionales versátiles, capaces de proponer y desarrollar proyectos en equipo o como unidades productoras unipersonales. <br/><br/>\r\nCon la carrera de Producción Audiovisual se promueve un perfil de profesional que además de desarrollar el potencial creativo y habilidades tecnológicas tenga solidez teórica que le permita comprender el fenómeno de la comunicación en que está inmerso en cada situación, su responsabilidad social y ética, así como saber adaptarse a las tecnologías por venir. \r\n</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<p>Para ser estudiante de la carrera el aplicante deberá: <br/><br/>\r\n<ul>\r\n <li>Ser una persona creativa, crítica y sensible al arte y al diseño. </li> <li> Ser proactivo y dispuesto a trabajar por objetivos.</li>\r\n<li>Tener habilidad para trabajos manuales o que involucren la construcción de objetos en dos o tres dimensiones. </li>\r\n<li>Tener habilidad para el dibujo artístico y técnico.</li>\r\n<li>Dominio muy básico del idioma inglés.</li>\r\n<li>Manejo básico de computador.</li>\r\n</p>\r\n\r\n[[Perfil de salida]]\r\n<p>Los conocimientos y habilidades que habrán de impartirse aseguran que el futuro profesional en Producción audiovisual obtenga la formación necesaria para:<br/><br/>\r\n<ul>\r\n<li>Comprender la función y posibilidades de las distintas áreas y roles que intervienen en la construcción del producto audiovisual. </li> <li>Generar y participar en proyectos adaptándose a distintas propuestas estéticas y presupuestarias.</li> <li> Valorar las diferentes manifestaciones audiovisuales reconociendo en las mismas su aporte como hecho comunicacional.</li>\r\n<li>Comprender, analizar y actuar desde el conocimiento de la complejidad del hecho audiovisual.</li>\r\n<li>Disponer de conocimientos y capacidad para crear, diseñar, producir, realizar y difundir productos audiovisuales en diferentes géneros.</li>\r\n<li>Contar con destrezas para trabajar interdisciplinariamente en equipos de investigación y de producción en el campo audiovisual.</li>\r\n<li>Conocimientos para desarrollar procesos de investigación relacionados con el campo audiovisual.</li>\r\n<li>Conocimientos y capacidades para detectar problemáticas estéticas propias de la producción audiovisual y gestionar propuestas innovadoras.</li>\r\n</p> \r\n\r\n[[Recursos Tecnológicos]] \r\n<p>Recursos recomendados. Sistema operativo Windows 7 64 bits. Sistema operativo Mac OS X, o superior. Al menos 4 gigabyte de RAM. Monitor con resolución al menos superior 1024 X 768 pixeles. Un procesador con no más de 3 años de antigüedad. Disco Duro de al menos 250 Gigas. Tableta Digitalizadora (recomendado) \r\n</p>\r\n\r\n[[Opciones de Seminarios]]\r\n<ul>\r\n<li>Actuación</li>\r\n<li>Dibujo Analítico</li>\r\n<li>Principios de sitios web</li>\r\n<li>Animación Bidimensional I</li>\r\n<li>Manipulación de la Imagen II</li>\r\n<li>Diagramación Digital</li>\r\n<li>Técnica Fotográfica I</li>\r\n<li>Diseño de Portafolio</li>\r\n</ul>\r\n\r\n[[Cursos afines]]\r\n<p>El conocimiento mínimo que se solicita para los cursos libres de la carrera sin tomar en cuenta el de Guión-Narrativa Audiovisual y Adobe Audition-Principios de Sonido, es el conocimiento básico operativo de Adobe Photoshop y Adobe Ilustrator</p>\r\n\r\n[[Requisitos para técnico]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03'),
(14, 3, 'Fotografía Digital', 's el siglo de la imagen y la comunicación visual, por lo tanto, Fotografía Digital se convierte en una carrera atractiva, accesible y desafiante.', '[[Descripción]]\r\n<p align="center"><b>"Fotografiar es colocar la cabeza, el ojo y el corazón en un mismo eje."<br/>\r\nHenry Cartier-Bresson  </b><br/><br/></p>\r\n\r\n<p>Es el siglo de la imagen y la comunicación visual, por lo tanto, Fotografía Digital se convierte en una carrera atractiva, accesible y desafiante. Nuestra maya curricular está conformada de tal manera, que con ella, el alumno recibe una formación integral tanto técnica, como teórica, viendo en el arte de la fotografía algo más que un proceso tecnológico con aplicaciones prácticas. A la par de un excelente currículo, el estudiante estará respaldado por lo último en tecnología digital y, específicamente en tecnología de la imagen.\r\n</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n[[Perfil de entrada]]\r\n<p>\r\n<ul>\r\n<li>Ser una persona creativa, crítica y sensible al arte y al diseño en general. </li> <li> Ser proactivo y dispuesto a trabajar por objetivos, individual y grupalmente.</li> <li> Dispuesto a asumir retos </li>\r\n</p>\r\n\r\n[[Perfil de salida]]\r\n<p>Las personas con el grado de Técnico en Fotografía Digital de Universidad Creativa, pueden desempeñarse, entre otras, en las siguientes ocupaciones: <br/><br/>\r\n<ul>\r\n<li>Administrador de su propia empresa. </li> \r\n<li>Fotógrafos en empresas especializados en eventos, promocionales y presentaciones públicas. \r\n</li> \r\n<li>Fotógrafo documental, de moda, publicitario, de medios impresos o digitales.</li> \r\n<li>Docente de la carrera de Fotografía Digital en Colegios, Institutos y Universidades. </li> \r\n<li>Integrante de grupos interdisciplinarios de trabajo. </li> \r\n</p> \r\n\r\n[[Recursos Tecnológicos]] \r\n<p>Cámara Fotográfica DSRL<br/>\r\nComputadora (editar fotografías, que tenga la capacidad para trabajar con programas como Adobe Photoshop y Adobe Lightroom)<br/>\r\nA partir del III cuatrimestre: Trípode, Flash externo)</p>\r\n\r\n\r\n[[Opciones de Seminarios]]\r\nComunicación y Sociedad<br/> \r\nSeminario de Color <br/>\r\nConstrucción de Páginas Web I <br/>\r\nHistoria del Arte y la Cultura  II  <br/>\r\nAdministración Empresarial <br/>\r\nApreciación del Arte <br/><br/>\r\nLos seminarios que se imparten anualmente en el evento Fotocreativa son incluidos dentro de las opciones:<br/>\r\n<ul>\r\n<li>Seminario de Fotografía: Luis Fabini (impartido en Fotocreativa 2009) </li>\r\n<li>Seminario de Fotografía: Foto Reportaje su Ritmo y Finalidad, fotógrafo: Carlos Cazurro (impartido en Fotocreativa 2010)</li> \r\n<li>Seminario de Fotografía: (Fotocreativa 2011) </li>\r\n\r\n[[Cursos afines]]\r\nImaginación y Creatividad<br/> Filosofía Contemporánea<br/> Administración Empresarial<br/> Técnicas de Investigación<br/> Economía, Contabilidad y Presupuestos<br/> Construcción de páginas web I<br/> Comercio Electrónico<br/> Análisis de Sitios Web<br/> Principios de sitios web<br/> Ética Profesional<br/> Construcción de Páginas Web<br/> Diagramación Digital<br/> Tipografía<br/> Apreciación del Arte Historia del Cine, el Video y la Televisión<br/> Narrativa Audiovisual I<br/> Escenografía <br/>\r\n\r\n[[Requisitos para técnico]]\r\n<p>\r\n<ol>\r\n<li>Tres Fotografías tamaño pasaporte</li>\r\n<li>Cédula (Original y Copia)</li>\r\n</ol>\r\n</p>\r\n\r\n\r\n[[', 'A', '2011-08-03', '2011-08-03');
INSERT INTO `tbl_careers` (`career_id`, `area_fk`, `career_name`, `career_description`, `career_text`, `career_status`, `career_created`, `career_modified`) VALUES
(18, 4, 'Cursos libres, entra y conócelos!', 'cursos libres', '[[Cursos Libres]]	\r\n<p>\r\n	<strong>Te&oacute;ricas y Talleres</strong><br />\r\n	<br />\r\n	<strong>Dise&ntilde;o del Paisaje I</strong></p>\r\n<p>\r\n	Te&oacute;rica/Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Con este curso el estudiante adquirir&aacute; conocimientos generales acerca del paisajismo y los elementos que lo conforman, tales como la flora de las regiones, elementos naturales y artificiales. El curso se divide en tres partes, una parte te&oacute;rica, una parte de investigaci&oacute;n y una tercera parte de dise&ntilde;o.<br />\r\n	<br />\r\n	<strong>Historia del Vestido I y II</strong><br />\r\n	<br />\r\n	(2 m&oacute;dulos)<br />\r\n	Te&oacute;rica /Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong></p>\r\n<p>\r\n	<strong><em>Historia del Vestido I:</em></strong> Introducir al estudiante a la investigaci&oacute;n y an&aacute;lisis de la historia del vestido. Se estudiar&aacute;n las diferentes teor&iacute;as sobre el origen de la vestimenta, adem&aacute;s del desarrollo del traje en diferentes &eacute;pocas y culturas.<br />\r\n	<em><strong>Historia del Vestido II:</strong></em> Curso te&oacute;rico-pr&aacute;ctico, introduce al estudiante en el an&aacute;lisis de la historia del vestido en las diversas &eacute;pocas as&iacute; como en el desarrollo de los conceptos sociales, econ&oacute;micos y pol&iacute;ticos que inciden en su creaci&oacute;n. Corresponde a la continuaci&oacute;n del curso de Historia del Vestido I.<br />\r\n	<br />\r\n	<strong>Seminario del Color</strong></p>\r\n<p>\r\n	Te&oacute;rica/Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	El prop&oacute;sito del curso de color ir&aacute; fundamentalmente encaminado a que el alumno descubra y conozca la teor&iacute;a y el an&aacute;lisis del color as&iacute; como sus posibilidades creativas y adquiera los conocimientos necesarios para potenciarlas y desarrollarlas al m&aacute;ximo.</p>\r\n<p>\r\n	<strong>Confecci&oacute;n I</strong><br />\r\n	Taller / Horas 8<br />\r\n	Categor&iacute;a D</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Conocer los elementos b&aacute;sicos de la confecci&oacute;n a mano y a m&aacute;quina para la elaboraci&oacute;n de productos textiles, el manejo de las principales m&aacute;quinas de coser a nivel artesanal e industrial, as&iacute; como la introducci&oacute;n a la t&eacute;cnica de modelado</p>\r\n<p>\r\n	<strong>Fotograf&iacute;a Digital Avanzada</strong></p>\r\n<p>\r\n	Te&oacute;rica/Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Este curso propone reafirmar los conocimientos t&eacute;cnicos del estudiante en fotograf&iacute;a. Apunta a comprender los diferentes estilos de fotograf&iacute;a mediante ejercicios pr&aacute;cticos, continuando as&iacute; en su desarrollo creativo.&nbsp;</p>\r\n<p>\r\n	<strong>Introducci&oacute;n a la Fotograf&iacute;a Digital</strong></p>\r\n<p>\r\n	Te&oacute;rica/Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Este curso propone conocer los elementos que estructuran una imagen fotogr&aacute;fica. Es una introducci&oacute;n a conocer y a explorar las posibilidades del lenguaje fotogr&aacute;fico. Apunta a comprender el funcionamiento de la c&aacute;mara fotogr&aacute;fica mediante ejercicios pr&aacute;cticos&nbsp; y a conocer los conceptos fundamentales de este lenguaje visualizando el trabajo de diferentes fot&oacute;grafos.</p>\r\n<p>\r\n	<strong>Taller de Joyer&iacute;a Accesorios Material</strong></p>\r\n<p>\r\n	Te&oacute;rica/Horas 3<br />\r\n	Categor&iacute;a B</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Creaci&oacute;n de joyer&iacute;a y accesorios utilizando diferentes t&eacute;cnicas con materiales de reciclaje variados y materiales de reh&uacute;so.<br />\r\n	<br />\r\n	<strong>Creatividad y Psicoan&aacute;lisis</strong></p>\r\n<p>\r\n	(2 m&oacute;dulos)<br />\r\n	Te&oacute;rica/Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Este curso pretende acercar a todos los participantes al radical discurso psicoanal&iacute;tico.<br />\r\n	Cada una de las reuniones que componen esta c&aacute;tedra intentar&aacute; ofrecerles a nuestros estudiantes los elementos necesarios para poder pensar psicoanal&iacute;ticamente, al menos a un nivel b&aacute;sico.<br />\r\n	La relaci&oacute;n entre lo inconsciente y la producci&oacute;n creativa rondar&aacute; el grueso de las discusiones. &iquest;Qu&eacute; busca expresar el ser humano cuando crea? &iquest;Qu&eacute; lo incita a crear? &iquest;A qui&eacute;n pertenece la obra, una vez ejecutada?</p>\r\n<p>\r\n	<strong>Fundamentos del Dise&ntilde;o</strong></p>\r\n<p>\r\n	Taller /Horas 6<br />\r\n	Categor&iacute;a C</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	El curso se desarrolla bajo la modalidad dual de 6 horas semanales, 3 horas te&oacute;ricas y 3 horas taller, abarcando conocimientos b&aacute;sicos de los Fundamentos del Dise&ntilde;o que ser&aacute;n aplicados a trabajos pr&aacute;cticos con el fin de afianzar la adquisici&oacute;n de aprendizajes significativos en el alumno, que le permitir&aacute;n aproximarse al mundo del dise&ntilde;o y sus principios universales convirti&eacute;ndose en la base de su futura carrera.</p>\r\n<p>\r\n	<strong>Introducci&oacute;n al Dibujo</strong></p>\r\n<p>\r\n	Te&oacute;rica/Horas 3<br />\r\n	Categor&iacute;a B</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	El curso de introducci&oacute;n al dibujo trata acerca de la presentaci&oacute;n y ejercicio de diversidad de t&eacute;cnicas y recursos existentes en el dibujo tradicional y experimental.&nbsp; Este curso pretende que el estudiante aprenda a observar de una manera diferente para que pueda ampliar su nivel de percepci&oacute;n.&nbsp; Se estudiar&aacute; procesos de hacer bocetos que le permitan al estudiante agilizar y organizar la representaci&oacute;n de elementos y su correspondiente composici&oacute;n.<br />\r\n	<br />\r\n	<strong>Taller de Modelado y Desgaste</strong></p>\r\n<p>\r\n	Taller /Horas 4<br />\r\n	Categor&iacute;a C</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Creaci&oacute;n y aplicaci&oacute;n de piezas m&aacute;ster desarrollo de prototipos para producci&oacute;n de piezas.&nbsp; T&eacute;cnica moldes de silic&oacute;n y acetato, choreado, aplicaci&oacute;n, encapsulado y fusi&oacute;n de materiales con&nbsp; resina y acr&iacute;licos.<br />\r\n	<br />\r\n	<strong>Dibujo Anat&oacute;mico</strong></p>\r\n<p>\r\n	Te&oacute;rica/Horas 3<br />\r\n	Categor&iacute;a B</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Este curso trata del estudio y representaci&oacute;n de los m&uacute;sculos y huesos del cuerpo humano, para lograr este fin se trabajara en la identificaci&oacute;n y memorizaci&oacute;n de cada una de las partes que los conforman, as&iacute; como sus detalles a nivel de volumen y estructuras, todo para una correcta representaci&oacute;n del desollado.</p>\r\n<p>\r\n	<strong>Historia de la Fotograf&iacute;a</strong><br />\r\n	Te&oacute;rica /Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	En este curso se identificar&aacute;n las diferentes l&iacute;neas expresivas de la fotograf&iacute;a a trav&eacute;s de la historia.&nbsp; Los estudiantes por medio del estudio de la historia de la fotograf&iacute;a ser&aacute;n capaces de desarrollar una sensibilidad art&iacute;stica que los llevara a ser m&aacute;s cr&iacute;ticos en la elaboraci&oacute;n de sus propias im&aacute;genes.<br />\r\n	<br />\r\n	<strong>Introducci&oacute;n al Dise&ntilde;o de Joyer&iacute;a y Accesorios</strong></p>\r\n<p>\r\n	Taller/ Horas 2<br />\r\n	Categor&iacute;a A<br />\r\n	<br />\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Estudio y an&aacute;lisis de las necesidades, funcionalidades, lenguaje, estilo y acabados de diferentes t&eacute;cnicas de producci&oacute;n y realizaci&oacute;n de piezas de autor, por medio de prototipos. Buscando la identidad de marca y provocando el estilo propio.<br />\r\n	<br />\r\n	<strong>Teor&iacute;a de la Imagen</strong></p>\r\n<p>\r\n	Teor&iacute;a /Horas 2<br />\r\n	Categor&iacute;a A<br />\r\n	<br />\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Esta clase consiste en el an&aacute;lisis de im&aacute;genes desde una &oacute;ptica conceptual, t&eacute;cnica y emotiva. La investigaci&oacute;n de lo real y lo aparente, impactante &oacute; trascendental que puede ser una imagen. El curso pretende que el estudiante pueda aplicar estos conocimientos&nbsp; en proyectos consisos, aut&eacute;nticos, creativos e innovadores, elaborados con una intensi&oacute;n preconcebida.</p>\r\n<p>\r\n	<strong>Dibujo Anal&iacute;tico</strong></p>\r\n<p>\r\n	Te&oacute;rica/Horas 3<br />\r\n	Categor&iacute;a B</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong></p>\r\n<p>\r\n	El dibujo anal&iacute;tico abarca la comprensi&oacute;n y dominio de los objetos s&oacute;lidos, reconociendo las estructuras lineales de sus conformaciones volum&eacute;tricas.&nbsp; Este curso pretende que los estudiantes de las diferentes carreras creativas consigan plasmar gr&aacute;ficamente cualquier figura a partir del razonamiento de las mismas.<br />\r\n	<br />\r\n	<strong>Historia del Arte y la Cultura I y II</strong></p>\r\n<p>\r\n	(3 m&oacute;dulos)<br />\r\n	Te&oacute;rica/Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	<em><strong>HISTORIA DEL ARTE Y LA CULTURA I:</strong></em> La asignatura introduce al estudiante en el an&aacute;lisis de su medio y, a trav&eacute;s de &eacute;l, de su cultura as&iacute; como la relaci&oacute;n del ser humano con otras culturas y &eacute;pocas espec&iacute;ficas. Cada tema consta de una presentaci&oacute;n hist&oacute;rico-cultural, apoyada por sesiones audio-visuales y actividades de co-gesti&oacute;n educativa.<br />\r\n	<em><strong>HISTORIA DEL ARTE Y LA CULTURA II: </strong></em>Este curso ampl&iacute;a en el estudiante los conocimientos adquiridos en el curso de Historia del Arte y la Cultura I, abarcando nuevos temas mediante el desarrollo de an&aacute;lisis sobre las especificidades culturales y art&iacute;sticas de otras civilizaciones. Adem&aacute;s estudia &eacute;pocas de caracteres y movimientos art&iacute;sticos muy definidos.<br />\r\n	<br />\r\n	<strong>Maquetas</strong></p>\r\n<p>\r\n	Taller /Horas 3<br />\r\n	Categor&iacute;a B</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	El curso de maquetas, pretende demostrar que maquetear es una habilidad que se adquiere con la pr&aacute;ctica y la disciplina, no es suficiente poseer los conocimientos del quehacer&nbsp; maquetero sino que desarrollen la habilidad de ser perfeccionistas y detallistas. Conceptuar un espacio nace de una experiencia mental, pero exhibir ese espacio a un p&uacute;blico es una habilidad que hay que aprender y explotar.<br />\r\n	Tener la capacidad para desarrollar, maquetas volum&eacute;tricas, de detalle, secciones y en gran escala, son parte del proceso del curso; como parte de este proceso es necesario conocer las escalas,&nbsp; los materiales, leer planos y dibujarlos. La representaci&oacute;n es parte imprescindible en el simbolismo de los objetos, las maquetas son objetos de an&aacute;lisis y de exhibici&oacute;n de all&iacute; que el curso busque y exija calidad. &nbsp;<br />\r\n	<br />\r\n	<br />\r\n	<strong>Vitrales</strong></p>\r\n<p>\r\n	Te&oacute;rica / Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Aplicaci&oacute;n de la t&eacute;cnica milenaria de vitrales estilo Tiffany, en piezas tridimensionales realizando todo el proceso totalmente a mano, creando esculturas en vitral.</p>\r\n<p>\r\n	<strong>Dibujo I Dise&ntilde;o de Modas</strong></p>\r\n<p>\r\n	Taller / Horas 4<br />\r\n	Categor&iacute;a C</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Curso cuatrimestral dividido en catorce sesiones de tipo taller, que introduce a los estudiantes a una de las herramientas m&aacute;s creativas para el dise&ntilde;o de modas, el dibujo.<br />\r\n	<br />\r\n	<strong>Historia del Cine Video y Televisi&oacute;n</strong></p>\r\n<p>\r\n	Te&oacute;rica / Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Este es un curso te&oacute;rico donde el estudiante aprender&aacute; acerca de la tecnolog&iacute;a del cine, video y televisi&oacute;n, que ha evolucionado, desde el primitivo cinemat&oacute;grafo mudo de los hermanos Lumi&egrave;re, hasta el cine digital del siglo XXI. Por otro lado, ha evolucionado el lenguaje cinematogr&aacute;fico, incluyendo las convenciones del g&eacute;nero, creando as&iacute; los g&eacute;neros cinematogr&aacute;ficos. En tercer lugar, ha evolucionado con la sociedad, surgiendo as&iacute; distintos movimientos cinematogr&aacute;ficos y cinematograf&iacute;as nacionales.<br />\r\n	<br />\r\n	<strong>Morfolog&iacute;a y Modelado</strong></p>\r\n<p>\r\n	Taller /Horas 2 Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Uso de material en forma y espacio tridimensional, comprensi&oacute;n, capacidad y dominio en el idioma f&iacute;sico volum&eacute;trico de un producto o personaje.<br />\r\n	<br />\r\n	<strong>Dise&ntilde;o de Patrones I</strong></p>\r\n<p>\r\n	Taller / Horas 4<br />\r\n	Categor&iacute;a C</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Curso tipo taller de 15 sesiones de cuatro horas cada una. Donde el estudiante conoce t&eacute;cnicas sencillas para realizar patrones b&aacute;sicos y diferentes transformaciones</p>\r\n<p>\r\n	<strong>Historia del Dise&ntilde;o Gr&aacute;fico</strong></p>\r\n<p>\r\n	Te&oacute;rica /Horas 2<br />\r\n	Categor&iacute;a A</p>\r\n<p>\r\n	<strong>Descripci&oacute;n del curso:</strong><br />\r\n	Curso te&oacute;rico cuatrimestral, de quince sesiones semanales de dos horas cada una, en las que el alumno estudiar&aacute; el desarrollo y evoluci&oacute;n del Dise&ntilde;o Gr&aacute;fico a trav&eacute;s de la historia.</p>\r\n\r\n[[', 'A', '2011-08-09', '2011-08-09'),
(19, 5, 'Creatividad Publicitaria', 'Creatividad Publicitaria', '<p>\r\n	[[Descripción]]</p>\r\n<p align="center">\r\n	&quot;La curiosidad en todos los aspectos de la vida es el secreto de las personas creativas&quot;&ndash; Leo Burnett</p>\r\n<p>\r\n	La visi&oacute;n del publicista moderno debe contextualizar la pr&aacute;ctica publicitaria como tan solo una de las herramientas dentro de un marco de comunicaci&oacute;n integrada de marketing, que involucra una serie de acciones paralelas pero intersecadas: relaciones p&uacute;blicas, periodismo comercial, marketing directo, promoci&oacute;n de ventas, ventas personales, emarketing y publicidad. Antes, el creativo publicitario deb&iacute;a pensar conceptos para aplicarlos en un comercial de televisi&oacute;n; hoy, los conceptos deben ser tan poderosos y extensibles como para que puedan ser aplicados transversalmente en todas las herramientas de la comunicaci&oacute;n integrada de marketing.</p>\r\n<p>\r\n	La Universidad Creativa es la primera instituci&oacute;n de educaci&oacute;n superior en Costa Rica en brindar al publicista las suficientes herramientas cognoscitivas, le modifique su forma de pensamiento (que es muy particular), y lo prepare adecuadamente para ejercer el puesto de creativo o redactor publicitario. La Carrera de Publicidad es un paso natural para la Universidad Creativa. Quien mejor que la Universidad Creativa, que desde su enfoque de pensamiento y metodolog&iacute;as acostumbradas a la innovaci&oacute;n del campo creativo per se, puede estar en la capacidad de ofrecer una carrera de Publicidad con enfoque en Creatividad Publicitaria, que preparar&aacute; al estudiante con las herramientas modernas para ejercer su profesi&oacute;n y una visi&oacute;n apegada a la realidad del mercado.</p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n<p>\r\n	[[Perfil de entrada]]</p>\r\n<p>\r\n	El estudiante de publicidad debe caracterizarse por:</p>\r\n<p>\r\n	Gran disposici&oacute;n para trabajar en comunicaci&oacute;n visual, oral, escrita etc.</p>\r\n<p>\r\n	Habilidades de expresi&oacute;n oral y escrita, con un uso correcto del idioma.&nbsp;</p>\r\n<p>\r\n	Gusto por el arte sin importar cu&aacute;l es el origen de esta, debe tener un punto de vista abierto a posibilidades y ser receptivo a nuevas herramientas.</p>\r\n<p>\r\n	Capacidad de adaptaci&oacute;n, alguien que no se limite a un tipo de trabajo especifico, el trabajo de los publicistas cambia y se reconfigura dependiendo de una gran cantidad de factores, desde el cliente y sus necesidades hasta los medios en los que se ha de pautar el trabajo.</p>\r\n<p>\r\n	Es una persona que se interesa por todo tipo de informaci&oacute;n, un publicista debe tener una amplia cultura general.</p>\r\n<p>\r\n	Apertura a la cr&iacute;tica y la autocritica, la mejor forma de evolucionar en la profesi&oacute;n es aprendiendo a aceptar los comentarios y acotaciones de quienes nos rodean.<br />\r\n	Capacidad de trabajar en equipo, compartiendo tanto responsabilidades como el cr&eacute;dito del trabajo.</p>\r\n<p>\r\n	Tener sentido del humor.&nbsp;</p>\r\n<p>\r\n	Es una persona interesada en relaciones p&uacute;blicas, periodismo comercial, marketing directo, promoci&oacute;n de ventas, ventas personales, e marketing y publicidad.</p>\r\n<p>\r\n	[[Perfil de salida]]</p>\r\n<p>\r\n	El egresado de la Carrera de Publicidad de la Universidad Creativa ser&aacute; un profesional con habilidades creativas multidisciplinarias sobresalientes, con una visi&oacute;n actualizada del mercado y de la realidad nacional, a la vanguardia tecnol&oacute;gica. Poseer&aacute; amplios conocimientos de mercadeo y de comunicaci&oacute;n; con una desarrollada actitud cr&iacute;tica y un fuerte pensamiento orientado a la innovaci&oacute;n.</p>\r\n<p>\r\n	[[Recursos tecnológicos]]</p>\r\n<p>\r\n	En la carrera de Publicidad es necesario tener una computadora que tenga la capacidad para trabajar con programas de como Adobe Photoshop, Adobe Illustrator, Adobe In Design; as&iacute; como paquete de Office.</p>\r\n<p>\r\n	PC, Mac (Escritorio o port&aacute;til). Requisitos recomendados: Sistema operativo Windows 7 64 bits. Sistema operativo Mac OS X, o superior. &nbsp;Al menos 2 gigabyte de RAM.<br />\r\n	Monitor con resoluci&oacute;n al menos superior 1024 X 768 pixeles.&nbsp;&nbsp;Un procesador con no m&aacute;s de 3 a&ntilde;os de antig&uuml;edad. Disco Duro de al menos 250 Gigas.</p>\r\n<p>\r\n	[[Opciones de seminarios]]</p>\r\n<p>\r\n	Imaginaci&oacute;n y Creatividad</p>\r\n<p>\r\n	Fotograf&iacute;a Digital</p>\r\n<p>\r\n	BTL &ndash; estrategia, creatividad y log&iacute;stica. (Convenio con Clandestina)</p>\r\n<p>\r\n	Copywriting (Convenio con Clandestina)</p>\r\n<p>\r\n	Insights (Convenio con Clandestina)</p>\r\n<p>\r\n	Historia del Cine, Video y Televisi&oacute;n</p>\r\n<p>\r\n	Principios de Sitios Web</p>\r\n<p>\r\n	Teor&iacute;a de la Imagen</p>\r\n<p>\r\n	[[CURSOS AFINES]]</p>\r\n<p>\r\n	Publicaci&oacute;n Electr&oacute;nica - FD-3011</p>\r\n<p>\r\n	Edici&oacute;n de Video Digital I AN-2054</p>\r\n<p>\r\n	Dibujo Digital I AN-3034</p>\r\n<p>\r\n	Manipulaci&oacute;n de la imagen para web I DSW-1022</p>\r\n<p>\r\n	Fotograf&iacute;a del Producto FD-1034</p>\r\n<p>\r\n	Introducci&oacute;n a la Publicidad</p>\r\n<p>\r\n	Planificaci&oacute;n de Medios</p>\r\n<p>\r\n	Comunicaci&oacute;n y Sociedad</p>\r\n<p>\r\n	E-marketing</p>\r\n<p>\r\n	[[Requisitos]]</p>\r\n<p>\r\n	Tres Fotograf&iacute;as tama&ntilde;o pasaporte<br />\r\n	C&eacute;dula (Original y Copia)</p>[[\r\n', 'A', '2011-10-27', '2011-10-27'),
(20, 5, 'Comunicación Digital', 'Comunicación Digital', '<p>\r\n	[[Descripción]]</p>\r\n<p align="center">\r\n	&ldquo;Si le damos a la gente el poder de compartir, haremos el mundo m&aacute;s transparente&rdquo;.</p>\r\n<p align="center">\r\n	- Mark Zuckerberg.</p>\r\n<p>\r\n	Los medios sociales han reinventado la forma en que nos comunicamos y han dado auge a nuevas ocupaciones como el community manager, el planificador de medios digitales, el programador de aplicaciones o el SEO.</p>\r\n<p>\r\n	El T&eacute;cnico Superior en Comunicaci&oacute;n Digital abarca tres grandes &aacute;reas: teor&iacute;a, talleres y emprendimiento, que le brindar&aacute;n al graduado las habilidades necesarias para adaptarse con facilidad al mercado del social media.</p>\r\n\r\n<p>\r\n\r\n[[Programa de carreras]]\r\n<p>==CUR_PRG_IMG==</p>\r\n\r\n	<strong>[[Perfil de entrada</strong>]]</p>\r\n<p>\r\n	La carrera de Comunicaci&oacute;n Digital es ideal no solo para profesionales que ya tienen un t&iacute;tulo universitario en carreras como periodismo, publicidad, relaciones p&uacute;blicas, filolog&iacute;a,&nbsp; producci&oacute;n de medios digitales, tecnolog&iacute;as de la informaci&oacute;n, psicolog&iacute;a, dise&ntilde;o gr&aacute;fico, politolog&iacute;a y sociolog&iacute;a que desean una actualizaci&oacute;n para su curr&iacute;culum; sino tambi&eacute;n para quienes son apasionados por los medios sociales y desean optar por una carrera corta.</p>\r\n<p>\r\n	<strong>[[Perfil de salida]]</strong></p>\r\n<p>\r\n	Los egresados de esta carrera estar&aacute;n capacitados para desempe&ntilde;arse como community manager en agencias de publicidad, de relaciones publicas, de medios publicitarios o de medios de comunicaci&oacute;n, en los departamentos de comunicaci&oacute;n o mercadeo de las compa&ntilde;&iacute;as o bien, emprender su propio negocio digital y crear su propia cartera de clientes.</p>\r\n<p>\r\n	<strong>[[Recursos Tecnol&oacute;gicos</strong>]]</p>\r\n<p>\r\n	Es indispensable ser usuario de redes sociales. Adem&aacute;s el estudiante necesitar&aacute; una computadora con la suficiente capacidad para utilizar programas de dise&ntilde;o, programaci&oacute;n y edici&oacute;n de video. Y por supuesto, un smartphone con acceso a internet.</p>\r\n<p>\r\n	<strong>[[Opciones de Seminarios]]</strong></p>\r\n<p>\r\n	Por definir</p>\r\n<p>\r\n	<strong>[[Cursos Libres afines</strong>]]</p>\r\n<p>\r\n	Fotograf&iacute;a Digital Avanzada</p>\r\n<p>\r\n	Fundamentos del Dise&ntilde;o</p>\r\n<p>\r\n	Edici&oacute;n de Video Digital I</p>\r\n<p>\r\n	Manipulaci&oacute;n de la imagen para web I</p>\r\n<p>\r\n	Manipulaci&oacute;n de la imagen para web II</p>\r\n<p>\r\n	Comercio Electr&oacute;nico</p>\r\n<p>\r\n	Principios de sitios Web</p>\r\n<p>\r\n	Construcci&oacute;n de P&aacute;ginas Web</p>\r\n<p>\r\n	Diagramaci&oacute;n Digital</p>\r\n<p>\r\n	<strong>[[Requisitos para t&eacute;cnico superior</strong>]]</p>\r\n<p>\r\n	Copia de la c&eacute;dula de identidad.</p>\r\n<p>\r\n	3 fotograf&iacute;as tama&ntilde;o pasaporte.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n[[', 'A', '2011-10-27', '2011-10-27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_events`
--

CREATE TABLE IF NOT EXISTS `tbl_events` (
  `event_id` bigint(20) NOT NULL auto_increment,
  `event_title` varchar(128) NOT NULL,
  `event_description` varchar(1024) NOT NULL,
  `event_url` varchar(128) NOT NULL,
  `event_status` varchar(1) NOT NULL default 'A',
  `event_created` date NOT NULL,
  `event_modified` date NOT NULL,
  PRIMARY KEY  (`event_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `tbl_events`
--

INSERT INTO `tbl_events` (`event_id`, `event_title`, `event_description`, `event_url`, `event_status`, `event_created`, `event_modified`) VALUES
(2, 'Alta Resolución', '<p>\n¡Buenas ideas, bien realizadas!<br/>\nAlta Resolución es el máximo evento del Área Gráfica de la Universidad Creativa; exposición que inició dentro de la carrera de Diseño Gráfico, y que hoy involucra a las carreras:\n<ul>\n<li>Desarrollo de Sitios Web</li>\n<li>Producción en Medios Digitales</li>\n<li>Modelado Digital en 3D</li>\n</ul>\nAlta Resolución representa una excelente oportunidad para que los estudiantes demuestren todo su talento y pasión. Además de la muestra de trabajos, la actividad sirve de marco para charlas y talleres con invitados destacados, que nos traen lo último en tendencias del mundo del diseño, con múltiples aplicaciones en el área gráfica. Este año, nuestro concurso de diseño aplicado trae la oportunidad de crear un ser imaginario, con enormes posibilidades artísticas, que les permitirá a los participantes desplegar todo su arsenal técnico y talento.\n</p>', 'http://ucreativa.com/altaresolucion2011', 'A', '2011-08-08', '2011-08-08'),
(3, 'Desfile de Modas', 'La Universidad Creativa le invita a su próximo desfile anual de modas, catalogado como el mejor del país. La cita es el sábado 20 de agosto a las 7 pm en la Antigua Aduana, en dónde recibimos alrededor de 2000 personas interesadas en la moda.<br/><br/>  Este año el desfile anual de modas de la Universidad Creativa se llama "Así Somos" y se inspira en Latinoamérica, tierra de contrastes, donde surgen y se fusionan diferentes culturas. Desde la época pre hispánica hasta la actualidad se ha nutrido de culturas autóctonas, foráneas, majestuosas, misteriosas y avanzadas, que se convirtieron en las raíces de lo que hoy se llama idiosincrasia latinoamericana.', 'http://ucreativa.com/fashionshow2011', 'A', '2011-08-16', '2011-08-16'),
(4, 'Fotocreativa 2011', 'La imagen en la sociedad actual, estableciendo patrones de conducta e influenciando relaciones virtuales y reales; la imagen como recurso de control social o de expresión personal de una época que posee los medios para realizarla y publicarla globalmente, desde los auto retratos para redes sociales hasta infinidad de aplicaciones comerciales o de seguridad, desde las bases de datos y sistemas biométricos de reconocimiento hasta la academia; de la publicidad a la narrativa y comunicación masiva.', 'http://www.ucreativa.com/fotocreativa2011', 'A', '2011-09-01', '2011-09-01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_files`
--

CREATE TABLE IF NOT EXISTS `tbl_files` (
  `file_id` bigint(20) NOT NULL auto_increment,
  `file_name` varchar(64) NOT NULL,
  `file_description` varchar(256) NOT NULL,
  `file_author` varchar(64) NOT NULL,
  `file_date` date NOT NULL,
  `file_type` varchar(16) NOT NULL,
  `file_first` varchar(1) NOT NULL default 'N',
  `file_status` varchar(1) NOT NULL default 'A',
  `file_created` date NOT NULL,
  `file_modified` date NOT NULL,
  PRIMARY KEY  (`file_id`),
  UNIQUE KEY `file_name` (`file_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=224 ;

--
-- Volcar la base de datos para la tabla `tbl_files`
--

INSERT INTO `tbl_files` (`file_id`, `file_name`, `file_description`, `file_author`, `file_date`, `file_type`, `file_first`, `file_status`, `file_created`, `file_modified`) VALUES
(2, 'banner_ucreativa.swf', 'banner inicial', 'Universidad Creativa', '2011-07-26', 'application/swf', 'N', 'A', '2011-07-26', '2011-07-26'),
(6, 'news.jpg', 'banner noticias', 'Universidad Creativa', '2011-07-23', 'image/jpg', 'N', 'A', '2011-09-21', '2011-09-21'),
(7, 'quienes.jpg', 'quienes banner', 'Universidad Creativa', '2011-07-29', 'image/jpg', 'Y', 'A', '2011-09-07', '2011-08-07'),
(8, 'conv.png', 'convenios bann', 'Universidad Creativa', '2011-08-01', 'image/png', 'N', 'A', '2011-08-01', '2011-08-01'),
(9, 'vid.jpg', 'vidau', 'Universidad Creativa', '2011-08-03', 'image/jpg', 'N', 'A', '2011-08-03', '2011-08-03'),
(10, 'amig.jpg', 'amigos', 'Universidad Creativa', '2011-08-03', 'image/jpg', 'N', 'I', '2011-08-03', '2011-08-03'),
(11, 'preg.jpg', 'preguntas', 'Universidad Creativa', '2011-08-03', 'image/jpg', 'N', 'I', '2011-08-03', '2011-08-03'),
(12, 'inver.jpg', 'inversion', 'Universidad Creativa', '2011-08-03', 'image/jpg', 'Y', 'A', '2011-08-03', '2011-08-03'),
(13, 'banner_3D.png', 'carreras', 'Universidad Creativa', '2011-08-03', 'image/png', 'Y', 'A', '2011-08-03', '2011-08-03'),
(14, 'arquitectura_1.jpg', 'arquitectura', 'Universidad Creativa', '2011-08-03', 'image/jpg', 'Y', 'A', '2011-08-03', '2011-08-08'),
(15, 'BDB1608.jpg', 'alta resolucion', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'Y', 'A', '2011-08-08', '2011-08-08'),
(16, 'BDB1645.jpg', 'alta resolucion', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(17, 'BDB1669.jpg', 'alta resolucion', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(18, 'BDB1687.jpg', 'alta resolucion', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(19, 'BDB1735.jpg', 'alta resolucion', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(20, 'BDB1847.jpg', 'alta resolucion', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(21, 'belgian_food_amanda_garron.jpg', 'new 2', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(22, 'giants_causeway.jpg', 'new 2', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'Y', 'A', '2011-08-08', '2011-08-08'),
(23, 'grindelwald.jpg', 'new 2', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(24, 'lyon.jpg', 'new 2', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(25, 'lyon2.jpg', 'new 2', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(26, 'monaco_fr.jpg', 'new 2', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(27, 'arquitectura_2.jpg', 'arqui', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(28, 'arquitectura_3.jpg', 'arqui', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(29, 'deco_1.jpg', 'deco', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'Y', 'A', '2011-08-08', '2011-08-08'),
(30, 'deco_2.jpg', 'deco', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(31, 'deco_3.jpg', 'deco', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(32, 'n1_foto_1.jpg', 'noti 1', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(33, 'n1_foto_2.jpg', 'noti 1', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'Y', 'A', '2011-08-08', '2011-08-08'),
(34, 'n1_foto_3.jpg', 'noti 1', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(35, 'n1_foto_4.jpg', 'noti 1', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(36, 'modas_1.jpg', 'modas', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'Y', 'A', '2011-08-08', '2011-08-08'),
(37, 'modas_2.jpg', 'modas', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(38, 'modas_3.jpg', 'modas', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(39, 'joyeria_1.jpg', 'joyeria', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'Y', 'A', '2011-08-08', '2011-08-08'),
(40, 'joyeria_2.jpg', 'joyeria', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(41, 'joyeria_3.jpg', 'joyeria', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(42, 'animacion_01.jpg', 'animacion', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'Y', 'A', '2011-08-08', '2011-08-08'),
(43, 'animacion_02.jpg', 'animacion', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(44, 'animacion_03.jpg', 'animacion', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(45, 'grafico_1.jpg', 'grafico', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'Y', 'A', '2011-08-08', '2011-08-08'),
(46, 'grafico_2.jpg', 'grafico', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(47, 'grafico_3.jpg', 'grafico', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(48, 'fotod_1.jpg', 'fotodigital', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'Y', 'A', '2011-08-08', '2011-08-08'),
(49, 'fotod_02.jpg', 'fotodigital', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(50, 'fotod_3.jpg', 'fotodigital', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(51, 'e_modas.jpg', 'eventos', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(52, 'alta_event.jpg', 'eventos', 'Universidad Creativa', '2011-08-08', 'image/jpg', 'N', 'A', '2011-08-08', '2011-08-08'),
(53, 'n4_1.jpg', 'Convenio Creativo-Clandestino', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(54, 'n4_2.jpg', 'Convenio Creativo-Clandestino', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'Y', 'A', '2011-08-16', '2011-08-16'),
(55, 'n4_3.jpg', 'Convenio Creativo-Clandestino', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(56, 'n4_4.jpg', 'Convenio Creativo-Clandestino', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(57, 'Horarios-III-Cuatrimestre-2011.pdf', 'Tabla de Categorías III cuatrimestre', 'Universidad Creativa', '2011-08-16', 'document/pdf', 'N', 'A', '2011-08-16', '2011-08-16'),
(58, 'Horario_IIIC-2011MALLA.pdf', 'Horario III C-2011', 'Universidad Creativa', '2011-08-16', 'document/pdf', 'N', 'A', '2011-08-16', '2011-08-16'),
(59, 'prg_3D.jpg', 'programa de cursos 3D', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(60, 'prg_animac.jpg', 'programa de cursos animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(61, 'prg_arqui.jpg', 'programa de cursos arquitectura', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(62, 'prg_dib_arqui.jpg', 'programa de cursos dibujo', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(63, 'prg_disenno_graf.jpg', 'programa de cursos diseño gráfico', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(64, 'prg_dis_intern.jpg', 'programa de cursos diseño interior', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(65, 'prg_espa_inter.jpg', 'programa de cursos espacio interno', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(66, 'prg_foto.jpg', 'programa de cursos foto', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(67, 'prg_joyas.jpg', 'programa de cursos joyas', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(68, 'prg_medios_digitales.jpg', 'programa de cursos medios digitales', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(69, 'prg_modas.jpg', 'programa de cursos modas', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(70, 'prg_textil.jpg', 'programa de cursos textil', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(71, 'prg_web.jpg', 'programa de cursos web', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(72, 'fashion2011_event.jpg', 'evento del desfile de modas 2011', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'Y', 'A', '2011-08-16', '2011-08-16'),
(73, 'banner_animac_digital.png', 'carrera animación digital', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(74, 'banner_arqui.png', 'carrera arquitectura', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(75, 'banner_dib_arq.png', 'carrera dibujo arquitectónico', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(76, 'banner_diseno_interior.png', 'carrera diseño interior', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(77, 'banner_diseno_grafico.png', 'carrera diseño gráfico', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(78, 'banner_foto_digital.png', 'carrera foto digital', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(79, 'banner_joyerias.png', 'carrera joyería', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(80, 'banner_medios_digitales.png', 'carrera medios digitales', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(81, 'banner_modas.png', 'carrera modas', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(82, 'banner_produccion_textil.png', 'carrera producción textil', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(83, 'banner_web.png', 'carrera web', 'Universidad Creativa', '2011-08-16', 'image/png', 'N', 'A', '2011-08-16', '2011-08-16'),
(84, 'gradas.jpg', 'quienes somos', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(85, 'mural.jpg', 'quienes somos', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(86, 'recepcion-sn-pedro.jpg', 'quienes somos', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(87, 'rio.jpg', 'quienes somos', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(88, 'sab.jpg', 'quienes somos', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(89, 'san-pedro_.jpg', 'quienes somos', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(90, 'zapote.jpg', 'quienes somos', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(91, 'compu2.jpg', 'Vida Universitaria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(92, 'danilo-montero.jpg', 'Vida Universitaria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(93, 'fotocreativa2.jpg', 'Vida Universitaria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(94, 'maquinas.jpg', 'Vida Universitaria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(95, 'soda.jpg', 'Vida Universitaria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(96, 'arquitectura_4.jpg', 'carrera de arquitectura', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(97, 'arquitectura_5.jpg', 'carrera de arquitectura', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(98, 'arquitectura_6.jpg', 'carrera de arquitectura', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(99, 'arquitectura_7.jpg', 'carrera de arquitectura', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(100, 'arquitectura_8.jpg', 'carrera de arquitectura', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(101, 'arquitectura_9.jpg', 'carrera de arquitectura', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(102, 'arquitectura_10.jpg', 'carrera de arquitectura', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(103, 'deco_4.jpg', 'carrera de decoración', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(104, 'deco_5.jpg', 'carrera de decoración', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(105, 'deco_6.jpg', 'carrera de decoración', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(106, 'deco_7.jpg', 'carrera de decoración', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(107, 'deco_8.jpg', 'carrera de decoración', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(108, 'deco_9.jpg', 'carrera de decoración', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(109, 'deco_10.jpg', 'carrera de decoración', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(110, 'modas_4.jpg', 'carrera de modas', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(111, 'modas_5.jpg', 'carrera de modas', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(112, 'modas_6.jpg', 'carrera de modas', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(113, 'modas_7.jpg', 'carrera de modas', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(114, 'modas_8.jpg', 'carrera de modas', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(115, 'modas_9.jpg', 'carrera de modas', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(116, 'joyeria_4.jpg', 'carrera de joyeria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(117, 'joyeria_5.jpg', 'carrera de joyeria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(118, 'joyeria_6.jpg', 'carrera de joyeria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(119, 'joyeria_7.jpg', 'carrera de joyeria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(120, 'joyeria_8.jpg', 'carrera de joyeria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(121, 'joyeria_9.jpg', 'carrera de joyeria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(122, 'joyeria_10.jpg', 'carrera de joyeria', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(123, 'animacion_04.jpg', 'carrera de animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(124, 'animacion_05.jpg', 'carrera de animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(125, 'animacion_06.jpg', 'carrera de animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(126, 'animacion_7.jpg', 'carrera de animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(127, 'animacion_8.jpg', 'carrera de animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(128, 'animacion_9.jpg', 'carrera de animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(129, 'animacion_13.jpg', 'carrera de animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(130, 'animacion_11.jpg', 'carrera de animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(131, 'animacion_12.jpg', 'carrera de animación', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(132, 'grafico_4.jpg', 'carrera de diseño gráfico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(133, 'grafico_5.jpg', 'carrera de diseño gráfico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(134, 'grafico_6.jpg', 'carrera de diseño gráfico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(135, 'grafico_7.jpg', 'carrera de diseño gráfico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(136, 'grafico_8.jpg', 'carrera de diseño gráfico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(137, 'grafico_9.jpg', 'carrera de diseño gráfico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(138, 'grafico_10.jpg', 'carrera de diseño gráfico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(139, 'fotod_4.jpg', 'carrera de fotografía digital', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(140, 'fotod_5.jpg', 'carrera de fotografía digital', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(141, 'fotod_6.jpg', 'carrera de fotografía digital', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(142, 'fotod_7.jpg', 'carrera de fotografía digital', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(143, 'fotod_8.jpg', 'carrera de fotografía digital', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(144, 'fotod_9.jpg', 'carrera de fotografía digital', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(145, 'fotod_10.jpg', 'carrera de fotografía digital', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(146, '3d_1.jpg', 'carrera de modelado digital 3d', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'Y', 'A', '2011-08-17', '2011-08-17'),
(147, '3d_2.jpg', 'carrera de modelado digital 3d', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(148, '3d_3.jpg', 'carrera de modelado digital 3d', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(149, '3d_4.jpg', 'carrera de modelado digital 3d', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(150, '3d_5.jpg', 'carrera de modelado digital 3d', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(151, '3d_6.jpg', 'carrera de modelado digital 3d', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(152, '3d_7.jpg', 'carrera de modelado digital 3d', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(153, '3d_8.jpg', 'carrera de modelado digital 3d', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(154, '3d_9.jpg', 'carrera de modelado digital 3d', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(155, 'da_1.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'Y', 'A', '2011-08-17', '2011-08-17'),
(156, 'da_2.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(157, 'da_3.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(158, 'da_4.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(159, 'da_5.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(160, 'da_6.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(161, 'da_7.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(162, 'da_8.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(163, 'da_9.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(164, 'da_10.jpg', 'carrera de dibujo arquitectónico', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(165, 'textil_1.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'Y', 'A', '2011-08-17', '2011-08-17'),
(166, 'textil_2.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(167, 'textil_3.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(168, 'textil_4.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(169, 'textil_5.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(170, 'textil_6.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(171, 'textil_7.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(172, 'textil_8.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(173, 'textil_9.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(174, 'textil_10.jpg', 'carrera de producción textil', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(175, 'web_1.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'Y', 'A', '2011-08-17', '2011-08-17'),
(176, 'web_2.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(177, 'web_3.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(178, 'web_4.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(179, 'web_5.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(180, 'web_6.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(181, 'web_7.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(182, 'web_8.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(183, 'web_9.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(184, 'web_10.jpg', 'carrera de diseño web', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'N', 'A', '2011-08-17', '2011-08-17'),
(185, 'new5_newsite.jpg', 'Nuevo sitio Web Ucreativa', 'Universidad Creativa', '2011-08-17', 'image/jpg', 'Y', 'A', '2011-08-17', '2011-08-17'),
(186, 'md_1.jpg', 'carrera de medios digitales', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'Y', 'A', '2011-08-16', '2011-08-16'),
(187, 'md_2.jpg', 'carrera de medios digitales', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(188, 'md_3.jpg', 'carrera de medios digitales', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(189, 'md_4.jpg', 'carrera de medios digitales', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(190, 'md_5.jpg', 'carrera de medios digitales', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(191, 'md_6.jpg', 'carrera de medios digitales', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(192, 'md_7.jpg', 'carrera de medios digitales', 'Universidad Creativa', '2011-08-16', 'image/jpg', 'N', 'A', '2011-08-16', '2011-08-16'),
(193, 'fotocreativa2011_event.jpg', 'evento fotocreativa 2011', 'ucreativa', '2011-09-01', 'image/jpg', 'Y', 'A', '2011-09-01', '2011-09-01'),
(194, 'asi_somos1.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Ucreativa', '2011-05-10', 'image/jpg', 'Y', 'A', '2011-10-05', '2011-10-05'),
(195, 'asi_somos2.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Ucreativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(196, 'asi_somos3.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Ucreativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(197, 'asi_somos4.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Ucreativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(198, 'asi_somos5.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Ucreativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(199, 'asi_somos6.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Ucreativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(200, 'fotocreativa_1.jpg', 'Fotocreativa 2011 y su concurso “La supremacía de la imagen” brilló y se lució con excelentes fotografías e invitados.', 'Ucreativa', '2011-10-05', 'image/jpg', 'Y', 'A', '2011-10-05', '2011-10-05'),
(201, 'fotocreativa_2.jpg', 'Fotocreativa 2011 y su concurso “La supremacía de la imagen” brilló y se lució con excelentes fotografías e invitados.', 'Ucreativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(202, 'fotocreativa_3.jpg', 'Fotocreativa 2011 y su concurso “La supremacía de la imagen” brilló y se lució con excelentes fotografías e invitados.', 'Ucreativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(203, 'fotocreativa_4.jpg', 'Fotocreativa 2011 y su concurso “La supremacía de la imagen” brilló y se lució con excelentes fotografías e invitados.', 'Ucreativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(204, 'fotocreativa_5.jpg', 'Fotocreativa 2011 y su concurso “La supremacía de la imagen” brilló y se lució con excelentes fotografías e invitados.', 'Universidad Creativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(205, 'fotocreativa_6.jpg', 'Fotocreativa 2011 y su concurso “La supremacía de la imagen” brilló y se lució con excelentes fotografías e invitados.', 'Universidad Creativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(206, 'asi_somos7.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Gabriela Calvo A.', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(207, 'asi_somos8.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Universidad Creativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(208, 'asi_somos9.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Universidad Creativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(209, 'asi_somos10.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Universidad Creativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(210, 'asi_somos11.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Universidad Creativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(211, 'asi_somos12.jpg', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica.', 'Universidad Creativa', '2011-10-05', 'image/jpg', 'N', 'A', '2011-10-05', '2011-10-05'),
(212, 'Silvia.jpg', 'Carrera Creatividad Publicitaria', 'Gabriela Calvo', '2011-10-27', 'image/jpg', 'Y', 'A', '2011-10-27', '2011-10-27'),
(213, 'comunicacion_01.jpg', 'Carrera de Comunicación', 'Universidad Creativa', '2011-10-31', 'image/jpg', 'Y', 'A', '2011-10-31', '2011-10-31'),
(214, 'comunicacion_02.jpg', 'Carrera de Comunicación', 'Universidad Creativa', '2011-10-31', 'image/jpg', 'N', 'A', '2011-10-31', '2011-10-31'),
(215, 'comunicacion_03.jpg', 'Carrera de Comunicación', 'Universidad Creativa', '2011-10-31', 'image/jpg', 'N', 'A', '2011-10-31', '2011-10-31'),
(216, 'comunicacion_04.jpg', 'Carrera de Comunicación', 'Universidad Creativa', '2011-10-31', 'image/jpg', 'N', 'A', '2011-10-31', '2011-10-31'),
(217, 'publicidad_01.jpg', 'Carrera de Publicidad', 'Universidad Creativa', '2011-10-31', 'image/jpg', 'Y', 'A', '2011-10-31', '2011-10-31'),
(218, 'publicidad_02.jpg', 'Carrera de Publicidad', 'Universidad Creativa', '2011-10-31', 'image/jpg', 'N', 'A', '2011-10-31', '2011-10-31'),
(219, 'publicidad_03.jpg', 'Carrera de Publicidad', 'Universidad Creativa', '2011-10-31', 'image/jpg', 'N', 'A', '2011-10-31', '2011-10-31'),
(220, 'prg_publi.jpg', 'programa de curso de publicación', 'Universidad Creativa', '2011-10-31', 'image/jpg', 'N', 'A', '2011-10-31', '2011-10-31'),
(221, 'prg_comu.jpg', 'programa de curso de comunicación', 'Universidad Creativa', '2011-10-31', 'image/jpg', 'N', 'A', '2011-10-31', '2011-10-31'),
(222, 'Mau.jpg', 'Carrera de Comunicación Digital', 'Gabriela Calvo A.', '2011-10-31', 'image/jpg', 'Y', 'A', '2011-10-31', '2011-10-31'),
(223, 'bus_ruta.jpg', 'Ruta del bus de la universidad creativa', 'Universidad Creativa', '2011-11-04', 'image/jpg', 'Y', 'A', '2011-11-04', '2011-11-04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_files_careers`
--

CREATE TABLE IF NOT EXISTS `tbl_files_careers` (
  `file_career_id` int(11) NOT NULL auto_increment,
  `file_fk` bigint(20) NOT NULL,
  `career_fk` int(11) NOT NULL,
  PRIMARY KEY  (`file_career_id`),
  KEY `file_fk` (`file_fk`),
  KEY `career_fk` (`career_fk`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=140 ;

--
-- Volcar la base de datos para la tabla `tbl_files_careers`
--

INSERT INTO `tbl_files_careers` (`file_career_id`, `file_fk`, `career_fk`) VALUES
(1, 14, 1),
(2, 27, 1),
(3, 28, 1),
(4, 43, 10),
(5, 29, 3),
(6, 30, 3),
(7, 31, 3),
(8, 36, 6),
(9, 37, 6),
(10, 38, 6),
(11, 39, 7),
(12, 40, 7),
(13, 41, 7),
(14, 42, 10),
(15, 44, 10),
(16, 45, 9),
(17, 46, 9),
(18, 47, 9),
(19, 48, 14),
(20, 49, 14),
(21, 50, 14),
(22, 59, 12),
(23, 60, 10),
(24, 61, 1),
(25, 62, 4),
(26, 63, 9),
(27, 64, 3),
(28, 65, 3),
(29, 66, 14),
(30, 67, 7),
(31, 68, 13),
(32, 69, 6),
(33, 70, 8),
(34, 71, 11),
(35, 96, 1),
(36, 97, 1),
(37, 98, 1),
(38, 99, 1),
(39, 100, 1),
(40, 101, 1),
(41, 102, 1),
(42, 103, 3),
(43, 104, 3),
(44, 105, 3),
(45, 106, 3),
(46, 107, 3),
(47, 108, 3),
(48, 109, 3),
(49, 110, 6),
(50, 111, 6),
(51, 112, 6),
(52, 113, 6),
(53, 114, 6),
(54, 115, 6),
(55, 116, 7),
(56, 117, 7),
(57, 118, 7),
(58, 119, 7),
(59, 120, 7),
(60, 121, 7),
(61, 122, 7),
(62, 123, 10),
(63, 124, 10),
(64, 125, 10),
(65, 126, 10),
(66, 127, 10),
(67, 128, 10),
(68, 129, 10),
(69, 130, 10),
(70, 131, 10),
(71, 132, 9),
(72, 133, 9),
(73, 134, 9),
(74, 135, 9),
(75, 136, 9),
(76, 137, 9),
(77, 138, 9),
(78, 139, 14),
(79, 140, 14),
(80, 141, 14),
(81, 142, 14),
(82, 143, 14),
(83, 144, 14),
(84, 145, 14),
(85, 146, 12),
(86, 147, 12),
(87, 148, 12),
(88, 149, 12),
(89, 150, 12),
(90, 151, 12),
(91, 152, 12),
(92, 153, 12),
(93, 154, 12),
(94, 155, 4),
(95, 156, 4),
(96, 157, 4),
(97, 158, 4),
(98, 159, 4),
(99, 160, 4),
(100, 161, 4),
(101, 162, 4),
(102, 163, 4),
(103, 164, 4),
(104, 165, 8),
(105, 166, 8),
(106, 167, 8),
(107, 168, 8),
(108, 169, 8),
(109, 170, 8),
(110, 171, 8),
(111, 172, 8),
(112, 173, 8),
(113, 174, 8),
(114, 175, 11),
(115, 176, 11),
(116, 177, 11),
(117, 178, 11),
(118, 179, 11),
(119, 180, 11),
(120, 181, 11),
(121, 182, 11),
(122, 183, 11),
(123, 184, 11),
(124, 186, 13),
(125, 187, 13),
(126, 188, 13),
(127, 189, 13),
(128, 190, 13),
(129, 191, 13),
(130, 192, 13),
(131, 213, 20),
(132, 214, 20),
(133, 215, 20),
(134, 216, 20),
(135, 217, 19),
(136, 218, 19),
(137, 219, 19),
(138, 220, 19),
(139, 221, 20);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_files_events`
--

CREATE TABLE IF NOT EXISTS `tbl_files_events` (
  `file_event_id` int(11) NOT NULL auto_increment,
  `file_fk` bigint(20) NOT NULL,
  `event_fk` bigint(20) NOT NULL,
  PRIMARY KEY  (`file_event_id`),
  KEY `file_fk` (`file_fk`),
  KEY `event_fk` (`event_fk`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `tbl_files_events`
--

INSERT INTO `tbl_files_events` (`file_event_id`, `file_fk`, `event_fk`) VALUES
(3, 52, 2),
(4, 72, 3),
(5, 193, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_files_news`
--

CREATE TABLE IF NOT EXISTS `tbl_files_news` (
  `file_new_id` int(11) NOT NULL auto_increment,
  `file_fk` bigint(20) NOT NULL,
  `new_fk` bigint(20) NOT NULL,
  PRIMARY KEY  (`file_new_id`),
  KEY `file_fk` (`file_fk`),
  KEY `new_fk` (`new_fk`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Volcar la base de datos para la tabla `tbl_files_news`
--

INSERT INTO `tbl_files_news` (`file_new_id`, `file_fk`, `new_fk`) VALUES
(1, 15, 3),
(2, 16, 3),
(3, 17, 3),
(4, 18, 3),
(5, 19, 3),
(6, 20, 3),
(7, 21, 2),
(8, 22, 2),
(9, 23, 2),
(10, 24, 2),
(11, 25, 2),
(12, 26, 2),
(13, 32, 1),
(14, 33, 1),
(15, 35, 1),
(16, 34, 1),
(17, 53, 4),
(18, 54, 4),
(19, 55, 4),
(20, 56, 4),
(21, 185, 5),
(22, 194, 6),
(23, 195, 6),
(24, 196, 6),
(25, 197, 6),
(26, 198, 6),
(27, 199, 6),
(28, 200, 7),
(29, 201, 7),
(30, 202, 7),
(31, 203, 7),
(32, 204, 7),
(33, 205, 7),
(34, 206, 6),
(35, 207, 6),
(36, 208, 6),
(37, 209, 6),
(38, 210, 6),
(39, 211, 6),
(40, 212, 8),
(41, 222, 9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_files_sections`
--

CREATE TABLE IF NOT EXISTS `tbl_files_sections` (
  `file_section_id` int(11) NOT NULL auto_increment,
  `file_fk` bigint(20) NOT NULL,
  `section_fk` int(11) NOT NULL,
  PRIMARY KEY  (`file_section_id`),
  KEY `file_fk` (`file_fk`),
  KEY `section_fk` (`section_fk`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Volcar la base de datos para la tabla `tbl_files_sections`
--

INSERT INTO `tbl_files_sections` (`file_section_id`, `file_fk`, `section_fk`) VALUES
(1, 2, 1),
(2, 6, 4),
(3, 7, 2),
(4, 8, 3),
(5, 9, 6),
(6, 10, 7),
(7, 11, 8),
(8, 12, 9),
(9, 13, 10),
(10, 51, 11),
(11, 57, 10),
(12, 58, 10),
(13, 73, 10),
(14, 74, 10),
(15, 75, 10),
(16, 76, 10),
(17, 77, 10),
(18, 78, 10),
(19, 79, 10),
(20, 80, 10),
(21, 81, 10),
(22, 82, 10),
(23, 83, 10),
(24, 84, 2),
(25, 85, 2),
(26, 86, 2),
(27, 87, 2),
(28, 88, 2),
(29, 89, 2),
(30, 90, 2),
(31, 91, 6),
(32, 92, 6),
(33, 93, 6),
(34, 94, 6),
(35, 95, 6),
(36, 223, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_links`
--

CREATE TABLE IF NOT EXISTS `tbl_links` (
  `link_id` int(11) NOT NULL auto_increment,
  `link_name` varchar(64) NOT NULL,
  `link_url` varchar(256) NOT NULL,
  `link_image` varchar(64) NOT NULL,
  `link_description` varchar(128) NOT NULL,
  `link_status` varchar(1) NOT NULL default 'A',
  `link_created` date NOT NULL,
  `link_modified` date NOT NULL,
  PRIMARY KEY  (`link_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Volcar la base de datos para la tabla `tbl_links`
--

INSERT INTO `tbl_links` (`link_id`, `link_name`, `link_url`, `link_image`, `link_description`, `link_status`, `link_created`, `link_modified`) VALUES
(1, 'unimercentroamerica', 'http://www.unimercentroamerica.com', 'unimercentroamerica.jpg', 'unimercentroamerica', 'A', '2011-08-03', '2011-08-03'),
(2, 'la506', 'http://www.la506.com', 'la506.jpg', 'la506', 'A', '2011-08-03', '2011-08-03'),
(3, 'sonrieme', 'http://www.sonrieme.org', 'sonrieme.jpg', 'sonrieme', 'A', '2011-08-03', '2011-08-03'),
(4, 'universidadescr', 'http://universidadescr.com', 'universidadescr.jpg', 'universidadescr', 'A', '2011-08-03', '2011-08-03'),
(5, 'clandestina', 'http://clandestina.cr', 'clandestina.jpg', 'clandestina', 'A', '2011-08-03', '2011-08-03'),
(6, 'revistabellasartes', 'http://www.revistabellasartes.com', 'revistabellasartes.jpg', 'revistabellasartes', 'A', '2011-08-03', '2011-08-03'),
(7, 'aseccss', 'https://www.aseccss.com/', 'aseccss.png', 'aseccss', 'A', '2011-10-25', '2011-10-25'),
(8, 'asefyl', 'http://www.asefyl.or.cr/', 'asefyl.jpg', 'asefyl', 'A', '2011-10-25', '2011-10-25'),
(9, 'asobancosta', 'http://www.asobancosta.com/', 'asobancosta.jpg', 'asobancosta', 'A', '2011-10-25', '2011-10-25'),
(10, 'asodicov', 'http://www.asodicov.com/ ', 'asodicov.jpg', 'asodicov', 'A', '2011-10-25', '2011-10-25'),
(11, 'asomega-logo', 'http://asomega.net/ ', 'asomega-logo.jpg', 'asomega-logo', 'A', '2011-10-25', '2011-10-25'),
(12, 'colper', 'http://www.colper.or.cr/', 'colper.jpg', 'colper', 'A', '2011-10-25', '2011-10-25'),
(13, 'fdmoda', 'http://www.fdmoda.com/es/inicio', 'fdmoda.jpg', 'fdmoda', 'A', '2011-10-25', '2011-10-25'),
(14, 'logo_ande', 'http://www.ande.cr/', 'logo_ande.jpg', 'logo_ande', 'A', '2011-10-25', '2011-10-25'),
(15, 'logo_asadem', 'http://www.asadem.com/', 'logo_asadem.gif', 'logo_asadem', 'A', '2011-10-25', '2011-10-25'),
(16, 'logo_asedp', 'http://solidarista.com/', 'logo_asedp.png', 'logo_asedp', 'A', '2011-10-25', '2011-10-25'),
(17, 'logo_asenacsa', 'http://www.asenacsa.com/', 'logo_asenacsa.jpg', 'logo_asenacsa', 'A', '2011-10-25', '2011-10-25'),
(18, 'logo_canatur', 'http://www.canatur.org/', 'logo_canatur.jpg', 'logo_canatur', 'A', '2011-10-25', '2011-10-25'),
(19, 'madc', 'http://www.madc.cr/ ', 'madc.jpg', 'madc', 'A', '2011-10-25', '2011-10-25'),
(20, 'ministerio_de_cultura', 'http://www.mcj.go.cr/ ', 'ministerio_de_cultura.jpg', 'ministerio_de_cultura', 'A', '2011-10-25', '2011-10-25'),
(21, 'sonylogo', 'http://www.sony.co.cr/', 'sonylogo.gif', 'sonylogo', 'A', '2011-10-25', '2011-10-25'),
(22, 'uci', 'http://www.uci.ac.cr/ ', 'uci.png', 'uci', 'A', '2011-10-25', '2011-10-25'),
(23, 'universidad_de_mexico', 'http://www.unam.mx/', 'universidad_de_mexico.jpg', 'universidad_de_mexico', 'A', '2011-10-25', '2011-10-25'),
(24, 'universidad_noreste_argentina', 'http://www.unne.edu.ar/ ', 'universidad_noreste_argentina.jpg', 'universidad_noreste_argentina', 'A', '2011-10-25', '2011-10-25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_news`
--

CREATE TABLE IF NOT EXISTS `tbl_news` (
  `new_id` bigint(20) NOT NULL auto_increment,
  `new_title` varchar(128) NOT NULL,
  `new_subtitle` varchar(128) default NULL,
  `new_description` varchar(256) NOT NULL,
  `new_text` text NOT NULL,
  `new_source` varchar(128) NOT NULL,
  `new_author` varchar(64) NOT NULL,
  `new_status` varchar(1) NOT NULL default 'A',
  `new_created` date NOT NULL,
  `new_modified` date NOT NULL,
  PRIMARY KEY  (`new_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Volcar la base de datos para la tabla `tbl_news`
--

INSERT INTO `tbl_news` (`new_id`, `new_title`, `new_subtitle`, `new_description`, `new_text`, `new_source`, `new_author`, `new_status`, `new_created`, `new_modified`) VALUES
(1, 'Barcelona destino de moda para los creativos', 'Barcelona destino de moda para los creativos', 'La ucreativa firmó un convenio con la Escuela Superior de Diseño y Moda FD, ubicada en Barcelona, España ', '<p>El sueño de muchos jóvenes universitarios es continuar sus estudios en reconocidas Universidades del extranjero; donde puedan obtener más conocimiento y experiencia, pero sobre todo buscan la oportunidad de colocarse en grandes empresas, o hasta tener su propio negocio. La Universidad Creativa consciente de ese deseo busca ofrecerles a sus estudiantes convenios con Universidades foráneas. En esta ocasión firmó un convenio con la Escuela Superior de Diseño y Moda FD, ubicada en Barcelona, España. Ésta es la única Escuela privada, autorizada por el departamento de Educación General de Cataluña. Una de las opciones para los estudiantes que opten por continuar sus estudios en FD Moda, es cursar el Máster en Gestión y Dirección de Empresas de Modas, que garantiza un plan estructurado, moderno y actual; y una titulación reconocida a nivel mundial.<br/><br/>\n\nAdemás ofrecen Maestría en Marketing, Comunicación y Organización de Eventos de Moda, Máster en Complementos y Accesorios de Modas, Máster en estilismo en Moda, Publicidad y Medios Audiovisuales, y Máster en Diseño de Modas. Adicionalmente imparten el Postgrado llamado Funciones del Dibujo en la creación del vestuario escénico y la moda. FD Moda también es parte de la famosa pasarela 080; este desfile lo impulsa el Departamento de Empresa y Empleo de la Generalidad de Cataluña y es el punto de encuentro del talento creativo, la industria y los compradores.<br/><br/>\n\nLa pasarela 080 es un referente de la generación y proyección en el sector de la moda. Este año se realizará del 12 al 15 de julio y contará con la presencia de unas 50 colecciones de diseñadores y marcas tanto nacionales como internacionales FD moda ofrece novedosos cursos de verano como Taller de estampado, Introducción a la Fotografía de moda, Introducción al Diseño de Calzado, Taller de construcción de bolsos y Personal shopper. En este último curso se adquieren los conocimientos necesarios para asesorar a clientes a la hora de elegir su vestuario, respetando su estilo personal y sus gustos. Imagínese que en Costa Rica tengamos personal capacitado en las mejores tiendas del país asesorándolo en sus compras. ¿No creen que sería un éxito? De seguro que con este convenio la industria de la moda costarricense también saldrá beneficiada. Quizá, por ser Barcelona una de las ciudades predilectas para los que buscan un entorno cosmopolita y de vanguardia, es que más del 33% de sus alumnos proceden del extranjero; y gracias a este convenio con la Universidad Creativa es probable que sus números suban un poco más.</p>\n\n<p align="right"><b>Gabriela Calvo A. / Universidad Creativa<br/> gabriela.calvo@ucreativa.com / info@ucreativa.com</b><br/><br/>\n\nImágenes propiedad de FD Moda\n', 'wikipedia', 'luis', 'A', '2011-07-26', '2011-07-26'),
(2, 'Naturaleza de día y ciudad de noche', 'Naturaleza de día y ciudad de noche', 'Es cierto eso del refrán que dice “querer es poder”, y así lo asume Amanda Garrón, estudiante de Fotografía Digital de la Universidad Creativa, quién sin graduarse ya cumplió uno de sus sueños. ', '<p>Es cierto eso del refrán que dice “querer es poder”, y así lo asume Amanda Garrón, estudiante de Fotografía Digital de la Universidad Creativa, quién sin graduarse ya cumplió uno de sus sueños. Una de sus fotos fue seleccionada para una nota de la revista National Geographic, conocida alrededor del mundo.<br/><br/>\nPero ¿cómo llega una estudiante de fotografía a alcanzar un logro como éste? Siempre le gusto fotografiar naturaleza y con un viaje que hizo por Europa hace meses terminó de comprobar ese enamoramiento por la cámara. Ella tomaba fotos de cada lugar que visitaba, desde el más conocido hasta el más recóndito. Fue así como se motivo a enviar algunas de sus mejores fotos a un par de concursos de National Geographic y tiempo después fue notificada de su elección para una nota llamada "Taste of travel" (El gusto de los viajes) .<br/><br/>\nEl objetivo de su viaje a Europa era estudiar francés y pensar que “hacer con su vida” como ella misma expresa; cuando al fin concluyó su viaje la respuesta era obvia, iba a estudiar Fotografía. Ahora en su carrera tratará de seguir realizando de sus fotografías favoritas que son principalmente de naturaleza, ciudades y comidas.<br/><br/>\nSu experiencia en Europa fue enriquecedora, conoció muchos lugares y acumuló anécdotas inolvidables; desde escalar una montaña por 7 horas sin el aparato que conecta el trípode con la cámara, hasta ser arrestada por no comprar el tiquete del tren en la estación, sino llevar el dinero en la mano, como solía hacerlo en Francia, donde se hospedó la mayor cantidad del tiempo. También en Lyon ganó un concurso de fotografía, con una de sus fotos favoritas.<br/><br/>\nAmanda ve en la fotografía una forma de expresarse, de trasmitir emociones a través de los lugares que ven sus ojos y que la enamora; “cada vez que veo algo que me gusta, le tomo una foto para trasmitir lo que estoy viviendo en ese momento”. Ella confiesa que le encanta jugar con la exposición de la luz.<br/><br/>\n“Me gustan mucho las fotos de noche, porque me encanta jugar con la luz; en cada ciudad que visité en Europa mi reto era tomar una fotografía de noche”. Ésta joven promesa de la fotografía también disfruta de tomar fotografía de comidas; de hecho cree que la foto que será publicada en la edición de octubre de la Revista National Geographic es sobre comida. Amanda cuenta que uno de los aspectos que hacen más famosos a Francia son sus comidas, así que cada vez que entraba en un restaurante si disponía a acomodar el escenario de su próxima foto gastronómica.\nPara los interesados en contactarla pueden escribirle a <b>amigm5@gmail.com </b></p>\n<p align="right"><b>Gabriela Calvo A.<br/> \nUniversidad Creativa</b></p>\n<p align="right"><b>gabriela.calvo@ucreativa.com / info@ucreativa.com\nwww.ucreativa.com</b></p>\n<p align="right">Crédito de fotografía: Amanda Garrón</p>\n', 'ucreativa', 'luis', 'A', '2011-07-27', '2011-07-27'),
(3, 'Alta Resolución en la casa del cuño ', 'Alta Resolución por lo alto ', 'Alrededor de 500 personas se dieron cita el pasado 20 de julio en la Casa del Cuño; todas ellas movidas por una misma razón, el gusto por el diseño.', '<p>Alrededor de 500 personas se dieron cita el pasado 20 de julio en la Casa del Cuño; todas ellas movidas por una misma razón, el gusto por el diseño. Poco a poco las personas empezaron a acercase para dar por inaugurada la tercera edición de Alta Resolución, el máximo evento del área gráfica de la Universidad Creativa.<br/><br/>\n\nEl primero en ofrecer la bienvenida fue el sub director administrativo, Oscar Romero, quién se mostró entusiasmado con el crecimiento que ha tenido la carrera y el evento. Además oficializó el convenio firmado con Clandestina Hub Creativo, centro especializado en las distintas áreas y enfocados en desarrollar el talento creativo e innovador en Costa Rica. Como parte de este convenio se contó con la presencia de Jorge Rivera, socio fundador de Clandestina, que explicó cómo surgió y hacia dónde va el convenio con ésta Universidad. <br/><br/>\n\nEl último en ofrecer la bienvenida y antes de cortar la cinta inaugural, fue el director de carrera Jonathan Quesada, quién se mostró muy emocionado con la exposición y con la respuesta de sus estudiantes; y no es para menos pues en esta ocasión y como nunca antes, participaron 200 estudiantes de diferentes cursos y talleres con la ilusión de ver su trabajo expuesto. Entre las técnicas desarrolladas utilizadas están ilustración, diseño editorial, catálogos, diseño de empaque, libros de marca, modelado en 3D, video, diseño Web y manipulación digital, entre otros. <br/><br/>\n\nEste año se exhibió una serie de diseños bajo el tema “Costa Rica-Nicaragua”, tema propuesto para contra restar tanto debate que se ha suscitado entre países en los últimos meses. En este salón temático se invitó a diseñadores nicaragüenses para tener la visión de ambos países. Entre las agencias nicaragüenses participantes están Huella, CCCP y Target Ogilvy; adicionalmente participa un diseñador de Jotabequ. En total este espacio cuenta con 27 diseños que intentan trasmitir un mensaje fraterno. <br/><br/>\n\nEn el diseño del nicaragüense, Jefferson Celebertti de la Agencia Huella, el mensaje expuesto es: “habrán diferencias pero seguimos siendo hermanos de tierras. Mismos gustos, mismas historias y mismas costumbres”. Por otra parte Enrique Saborío, Gerente de Ogilvy, diseñador tico radicado en Nicaragua, comentó desde la invitación que se sentía muy motivado con la idea de unir ambos países por medio de la gráfica y motivó a los diseñadores de la agencia a participar. <br/><br/>\n\nOtros de los diseños expuestos son monstruos, diseños realizados para campañas publicitarias y diseños realizados para pequeñas empresas. Los diseños realizados para el Monstruario son parte de un concurso, que tiene como  mecánica el  voto del público y curación de un jurado. El ganador se anunciará el 28 de julio, fecha en que finaliza Alta Resolución. <br/><br/>\n\nAlta Resolución también ofrece charlas abiertas al público en general, con expositores de muy alto nivel. Esta semana se ofrecerán dos charlas y son: martes 26 de julio: “Redes sociales y emprendedurismo” por Mauricio Fallas, director de la Unidad Digital de Unimer; y jueves 28 de julio: “El proceso creativo en la creación tipográfica experimental” por Miguel Cabrera, Director Asociado del Área Gráfica de Clandestina Hub Creativo. <br/><br/>\n\nPara los interesados en visitar la exposición, estará disponible hasta el jueves 28 de julio, en horario de 10:00 a.m. a 8:00 p.m. La entrada es gratuita.</p>\n\n<p align="right"><b>Gabriela Calvo A.<br/> \nUniversidad Creativa</b></p>\n<p align="right"><b>gabriela.calvo@ucreativa.com / info@ucreativa.com\nwww.ucreativa.com</b></p>\n<p align="right">Crédito de fotografía: Bryan Díaz </p>\n', 'ucreativa', 'luis', 'A', '2011-08-08', '2011-08-08'),
(4, 'Convenio Creativo-Clandestino', 'Convenio Creativo-Clandestino', 'Ucreativa+Clandestina Hub Creativo: Aspirar a ser grande, ser grande y que te vean grande profesionalmente, es una de las expectativas para muchos creativos, que buscan mejorar y ampliar conocimientos.', '<p>Aspirar a ser grande, ser grande y que te vean grande profesionalmente, es una de las expectativas para muchos creativos, que buscan mejorar y ampliar conocimientos. Quizá por esa razón es que dos importantes centros de estudio para creativos firmaron un prometedor convenio hace un par de semanas. Se trata de la Universidad Creativa y de Clandestina Hub Creativo.<br/><br/>\r\nLa Universidad Creativa es conocida por muchas personas, pues cuenta con más de 16 años procurando ser una entidad formal donde los jóvenes creativos se puedan desarrollar. Sus carreras son dirigidas al área del diseño y la comunicación visual; entre ellas:<br><br> Diseño Gráfico, Arquitectura, Diseño de Modas, Fotografía Digital, Producción en Medios Digitales, Animación Digital y Desarrollo de Sitios Web.<br/><br/>\r\nClandestina por su parte convoca a líderes emprendedores en distintas áreas para crear nuevos cursos enfocados en contribuir decididamente al desarrollo creativo e innovador de Costa Rica. A la vez, desarrollaron un novedoso concepto de aprendizaje que se adapta a la sociedad tan cambiante en la que vivimos. Hoy es un HUB CREATIVO; es decir, un punto de conexión entre el pensamiento y el talento innovador para viajar a otras áreas de la sociedad.<br/><br/>\r\nOscar Romero, sub-gerente general, explica que este convenio beneficia a ambas partes, “consiste en ofrecer descuentos tanto a estudiantes de la Universidad en Clandestina, como a estudiantes de Clandestina en la Universidad. Además otro de los objetivos es generar una retroalimentación en el área docente, desarrollar proyectos innovadores en conjunto con el fin de mejorar y ofrecer más oportunidades a los estudiantes de ambos centros educativos”.<br/><br/>\r\n\r\nPor estar a la vanguardia se mejorará el nivel y se crearán oportunidades nuevas para los estudiantes. Además se diseñarán talleres de Clandestina para ofertarse como Seminarios de la Universidad y este III Cuatrimestre del 2011 se ofertará los primeros dos. Estos son: Tipografía Experimental y Creatividad Publicitaria.<br/><br/>\r\n\r\nEn el caso del Seminario de Tipografía Experimental pretende el acercamiento a la creación de tipografías experimentales, ornamentales o también conocidas como tipografías de fantasía, para diferentes medios de aplicación o uso. El proceso creativo busca la manera de crear una tipografía con un concepto definido, pero que permita al diseñador una libertad de ejecución.<br/><br/> \r\n\r\nPor otra parte el Seminario de Creatividad Publicitaria busca que cada alumno finalice el seminario con una carpeta que represente la singularidad de su trabajo. Que sea, desde la conceptualización y la creatividad aplicada, algo tan único y personal como su ADN. <br/><br/>\r\n\r\nCon este convenio se beneficiarán todas las áreas de Diseño de la Universidad, pues la idea es que los diferentes Seminarios sean generados para todas las carreras de la Institución. <br/><br/>\r\n\r\n<b><p align="right">Gabriela Calvo A.<br/> Universidad Creativa/gabriela.calvo@ucreativa.com </b><br/><br/>Crédito de fotos: Bryan Díaz y <b>www.clandestina.cr</b></p> \r\n', '', '', 'A', '2011-08-16', '2011-08-16'),
(5, '¡Lanzamos nuestro nuevo Site!', 'Lanzamos nuestro nuevo Site ', 'Conscientes de la necesidad de ofrecer a los estudiantes mejores servicios y calidad de información, la Universidad Creativa decidió construir una página Web de fácil navegación y con toda una plataforma de Servicios.', 'Lanzamos nuestro nuevo Site \r\n<p>Conscientes de la imperante necesidad de ofrecer a los estudiantes mejores servicios y calidad de información, la Universidad Creativa decidió construir una página Web de fácil navegación y con toda una plataforma de Servicios en la nube, con lo que pretende situarse a la vanguardia de las tecnologías de la información.<br/><br/>\r\nOscar Romero, sub director general de la Universidad, afirma que el objetivo no es dar un paso, es dar un salto hacia un proceso de automatización e integración de sistemas y plataformas de servicios para que tanto nuestros estudiantes, provedores, profesores y administrativos utiilicen las mejores herramientas del mercado, unificando procedimientos y simplificándolos. El sitio será un directorio de información, un punto de encuentro y comunicación. <br/><br/>\r\nCada lunes a partir de mayo un grupo responsable se reunió para lograr un objetivo, contar con una página Web más accesible y amigable. El proceso inició con un estudio de las deficiencias de la página vieja y continuó con una lluvia de ideas de lo que tenía que poseer la página para cumplir con las expectativas de los estudiantes. <br/><br/>\r\nEstá es la primera etapa de un total de cinco, las cuales están planeadas terminarse para enero del 2012, según el señor Romero el tamaño del sitio no es tan importante como las características internas del mismo, ya que a través de procesos internos el mismo podrá actualizarse e integrarse con otras plataformas en línea de la universidad en tiempo real, brindando confianza al consumidor. <br/><br/>\r\nEntre las principales características de la página está que cada carrera contará con el programa, los recursos tecnológicos que necesitará el estudiante, las opciones de Seminarios para requisito de Graduación y algunos cursos afines que le puede interesar llevar, entre otras cosas. En las etapas siguientes se incluirán mecanismos de comunicación bidireccional que colaborarán con la horizontalidad de la comunicación con las áreas funcionales y académicas de la Universidad. <br/><br/>\r\nAdemás cada evento de la Universidad tendrá su propio Micro sitio, por ejemplo Alta Resolución, Desfile Anual de Modas, Fotocreativa y todos los que estén por crearse para las diferentes carreras. <br/><br/>\r\nLos principales servicios que se ofrecerán en la nueva plataforma, a partir del 2012 son: <br/><br/>\r\n<ul>\r\n<li>Servicio de Biblioteca Virtual</li>\r\n<li>Matrícula en línea</li>\r\n<li>Cursos virtuales</li>\r\n<li>Calendarios institucionales</li>\r\n<li>Servicios de información</li>\r\n</ul>\r\n<i>¡Esperamos que esta sea una muy buena noticia para todos ustedes!</i>\r\n<br/><br/>\r\n<b>Nuestro equipo de trabajo</b><br/><br/>\r\nOscar Romero, sub director general<br/><br/>\r\nGiselle Meléndez, directora de mercadeo<br/><br/>\r\nMauricio Fallas, creativo y asesor publicitario<br/><br/>\r\nGabriela Calvo, coordinadora de comunicación<br/><br/>\r\nJosé Fernández, coordinador de diseño gráfico<br/><br/>\r\nAdelso Ortega, diseñador  gráfico<br/><br/>\r\nJean Carlo Castro, diseñador gráfico<br/><br/>\r\nJosé Carlo Vargas, diseñador gráfico<br/><br/>\r\nMario Navarro, ingeniero senior<br/><br/>\r\nLuis Miguel Morales, diseñador gráfico & web<br/><br/>\r\nDeiver Herrera, programador & DBA<br/><br/>\r\n</p>\r\n', 'ucreativa', 'gabriela', 'A', '2011-08-17', '2011-08-17'),
(6, '“Así somos” todo un éxito', '“Así somos” todo un éxito', 'Así Somos 2011 tuvo como tema de inspiración a Latinoamérica; todas sus culturas, costumbres, religiones y formas de vida que existen a lo largo y ancho de esta tierra llena de contrastes.', '<p>\r\n	<style type="text/css">\r\n<!--\r\n		@page { margin: 2cm }\r\n		P { margin-bottom: 0.21cm }\r\n		A:link { so-language: zxx }\r\n	-->	</style>\r\n	As&iacute; Somos 2011 tuvo como tema de inspiraci&oacute;n a Latinoam&eacute;rica; todas sus culturas, costumbres, religiones y formas de vida que existen a lo largo y ancho de esta tierra llena de contrastes. Tierra que con toda esa fusi&oacute;n se convirti&oacute; en las ra&iacute;ces de lo que hoy llamamos idiosincrasia latinoamericana.<br />\r\n	<br />\r\n	Los estudiantes de la carrera de Dise&ntilde;o de Modas como cada a&ntilde;o fueron los responsables de darle vida a la pasarela; desde los estudiantes de Introducci&oacute;n al Dise&ntilde;o de Modas, que como es usual, tienen m&aacute;s libertad al desarrollar sus propuestas, con trajes conceptuales (no para la venta); hasta los dem&aacute;s niveles de dise&ntilde;o, donde tienen la opci&oacute;n de ser 100% comerciales. En el caso de los proyectos de graduaci&oacute;n son casi todos 100% comerciales, pues est&aacute;n ya dirigidos a colocar y vender la colecci&oacute;n, debido a que es una gran inversi&oacute;n.<br />\r\n	<br />\r\n	Las colecciones estaban inspiradas en pinturas de artistas latinoamericanos, en iglesias, en culturas ind&iacute;genas, en ritmos musicales como el tango y en personajes sobresalientes como Frida Kahlo. 43 estudiantes expusieron sus dise&ntilde;os; entre ellos 5 egresados que presentaron su proyecto de graduaci&oacute;n. En el caso de los Proyectos de Graduaci&oacute;n todos tienen diferentes temas de inspiraci&oacute;n libres y es un trabajo m&aacute;s elaborado pues de eso depende su titulaci&oacute;n como dise&ntilde;ador de modas.<br />\r\n	<br />\r\n	Los modelos que estuvieron en pasarela son Andrea Soto, Natasha Fleming, Carina Dietz, Jessica Sol&iacute;s (Elite Model Look 2010), Andrea Robert, Jessica Gonz&aacute;lez (2do lugar Modelo Perfil 2010), Rachel Stewart, Ivonne Cerdas (1er lugar Modelo Perfil 2010), Estefan&iacute;a Castro (3er lugar Modelo Perfil 2010), Francini Obando, M&oacute;nica Orozco, Zoe Polson, Ekaterina S&aacute;nchez, Elisa L&oacute;pez, Iv&aacute;n Salas, Roberto Truque, Bryan Stewart, Gary Bravo, Fabi&aacute;n Alvarado, David Lopez Araya, Tom&aacute;s Rub&eacute;n Oreamuno, Jos&eacute; Pablo Hern&aacute;ndez, Gabriel Garro (Mr. Costa Rica 2006) y Juan Pablo Brenes.<br />\r\n	<br />\r\n	Tambi&eacute;n contamos con la honorable presencia de Leonora Jim&eacute;nez, reconocida modelo nacional que se ha proyectado a nivel internacional. Ella realiz&oacute; su primera pasarela con nuestra Universidad y &eacute;sta fue la &uacute;ltima de su carrera. Agradecemos el gran apoyo que brinda Leonora a nuestra Universidad, pero en especial el apoyo que brinda al dise&ntilde;o nacional.<br />\r\n	<br />\r\n	Los estudiantes fueron evaluados por un distinguido jurado, compuesto por Mar&iacute;a Lourdes Castro, dise&ntilde;adora de modas y profesora de nuestra universidad; Marcelle Desanti, dise&ntilde;adora de modas y gerente de la Tienda Max Mara en Costa Rica; Glenda Ch&aacute;vez, dise&ntilde;adora de modas independiente; Armando del Vecchio, reconocido fot&oacute;grafo y Juan Ignacio Salom, arquitecto y gerente general de la Boutique Kiosco San Jos&eacute;.<br />\r\n	<br />\r\n	Sobre la producci&oacute;n del desfile, en su mayor&iacute;a es realizada por los mismos estudiantes y profesores de Dise&ntilde;o de Modas. La escenograf&iacute;a est&aacute; a cargo de estudiantes de Dise&ntilde;o Interior; las responsables del dise&ntilde;o son Priscilla Z&uacute;&ntilde;iga y Paola Bejarano.<br />\r\n	<br />\r\n	<strong>Gabriela Calvo A. / Universidad Creativa<br />\r\n	gabriela.calvo@ucreativa.com<br />\r\n	Cr&eacute;dito de fotograf&iacute;a: Bryan D&iacute;az</strong></p>\r\n', 'Ucreativa', 'Gabriela Calvo', 'A', '2011-10-05', '2011-10-05'),
(7, 'Supremacía de la imagen', 'Supremacía de la imagen', 'Fotocreativa 2011 y su concurso “La supremacía de la imagen” brilló y se lució con excelentes fotografías e invitados. La inauguración se llevó a cabo con un llenazo el pasado viernes 16 de setiembre a las 7 p.m. en la Casa del Cuño.', '<p>\r\n	Fotocreativa 2011 y su concurso &ldquo;La supremac&iacute;a de la imagen&rdquo; brill&oacute; y se luci&oacute; con excelentes fotograf&iacute;as e invitados. La inauguraci&oacute;n se llev&oacute; a cabo con un llenazo el pasado viernes 16 de setiembre a las 7 p.m. en la Casa del Cu&ntilde;o.<br />\r\n	<br />\r\n	Al ser las 7:15 p.m. la Fundadora de la Universidad Creativa, Mar&iacute;a Madrigal, de forma muy emotiva agradeci&oacute; la asistencia y la confianza que los padres de familia depositan en este Centro de Ense&ntilde;anza. Luego Don Oscar Romero, sub director administrativo, cont&oacute; sobre las primeras experiencias de la carrera de Fotograf&iacute;a Digital y Marcela Alarc&oacute;n, directora de carrera agradeci&oacute; la participaci&oacute;n de los estudiantes que se arriesgaron a participar y reafirm&oacute; la importancia de la visita de Luis Beltr&aacute;n, invitado de honor que imparte el Seminario de &ldquo;Revelado digital y fotograf&iacute;a creativa&rdquo;.<br />\r\n	<br />\r\n	Como parte de la inauguraci&oacute;n el fot&oacute;grafo espa&ntilde;ol Luis Beltr&aacute;n dio la charla &ldquo;Vivir un sue&ntilde;o&rdquo;, haciendo referencia a lo duro y gratificante que es desempe&ntilde;arse en la fotograf&iacute;a, que es una de sus mayores pasiones. Adem&aacute;s comparti&oacute; una muestra de sus primeras fotograf&iacute;as.<br />\r\n	La exposici&oacute;n estaba compuesta por una muestra de fotograf&iacute;as de 56 estudiantes, fotograf&iacute;as de nuestros artistas invitados: Gloria Calder&oacute;n, Mario Peraza, Carlos Quesada, Gustavo Guti&eacute;rrez, Luis Beltr&aacute;n y Colectivo 7. Adem&aacute;s de una muestra con 33 retratos de estudiantes de las diferentes carreras de la Universidad; que pretende mostrar la imagen de la Universidad.<br />\r\n	<br />\r\n	El concurso &ldquo;La supremac&iacute;a de la imagen&rdquo; fue curado por Luis Beltr&aacute;n, Gloria Calder&oacute;n, Mario Peraza, Carlos Mar&iacute;n (representante de Sony) y Marcela Alarc&oacute;n. El ganador del 1er lugar fue Oscar Quesada Bravo con su obra &ldquo;Esculpiendo el cuerpo de los dioses&rdquo;&nbsp; y el 2do lugar qued&oacute; empate entre Sergio Zeled&oacute;n Rodr&iacute;guez y Sylvia Gonz&aacute;lez Navarrete. La fotograf&iacute;a de Sylvia la titul&oacute; &quot;Beautiful People&quot; y la serie de Sergio Zeled&oacute;n se llama &ldquo;Redes Sociales&rdquo;.<br />\r\n	Adicionalmente se seleccionaron cuatro menciones de honor, los estudiantes que las obtuvieron son: Mario Campos Retana, Karina Ocampo Alvarado, Enrique Runnebaum Jim&eacute;nez y Alejandra V&aacute;squez Portilla.<br />\r\n	<br />\r\n	Luis Beltr&aacute;n, afirm&oacute; que no esperaba encontrarse con una exposici&oacute;n tan bien organizada; en un lugar tan bonito y con este tipo de montaje, &ldquo;a nivel t&eacute;cnico y art&iacute;stico hay una serie de obras que me han gustado bastante&hellip; a nivel general me he quedado muy impresionado con lo que he visto&rdquo;.<br />\r\n	<br />\r\n	<strong>Gabriela Calvo A. / Universidad Creativa<br />\r\n	gabriela.calvo@ucreativa.com<br />\r\n	www.ucreativa.com<br />\r\n	Cr&eacute;dito de fotograf&iacute;as: Oscar Quesada, Sylvia Gonz&aacute;lez, Sergio Zeled&oacute;n, Karina Ocampo, Marco Campos, Alejandra V&aacute;squez y Enrique Runebaum.</strong></p>\r\n', 'Ucreativa', 'Gabriela Calvo A.', 'A', '2011-10-05', '2011-10-05'),
(8, 'Creatividad Publicitaria', 'Creatividad Publicitaria', 'Las carreras del área gráfica son apetecidas por una gran mayoría de creativos. El Diseño Gráfico y la Publicidad son dos de esas carreras y ahora por primera vez en Costa Rica la especialización en Creatividad Publicitaria.', '<p>\r\n	Las carreras del &aacute;rea gr&aacute;fica son apetecidas por una gran mayor&iacute;a de creativos. El Dise&ntilde;o Gr&aacute;fico y la Publicidad son dos de esas carreras y ahora por primera vez en Costa Rica la especializaci&oacute;n en Creatividad Publicitaria. La responsable es la Universidad Creativa, que tiene planeado implementar la carrera de Publicidad con un &eacute;nfasis en Creatividad Publicitaria.</p>\r\n<p>\r\n	Para este 2011 se arranca impartiendo el T&eacute;cnico Superior en Creatividad Publicitaria, con la direcci&oacute;n de la publicista Silvia Mar&iacute;n y con una plana de profesores que se encargar&aacute;n de ir formando estos nuevos profesionales. Silvia afirma que la Universidad Creativa es la mejor opci&oacute;n para los interesados en desarrollar su creatividad.</p>\r\n<p>\r\n	&ldquo;El egresado de &eacute;sta carrera ser&aacute; un profesional con habilidades creativas multidisciplinarias sobresalientes, con una visi&oacute;n actualizada del mercado y de la realidad nacional, a la vanguardia tecnol&oacute;gica. Poseer&aacute; amplios conocimientos de mercadeo y de comunicaci&oacute;n; con una desarrollada actitud cr&iacute;tica y un fuerte pensamiento orientado a la innovaci&oacute;n&rdquo; afirm&oacute; Silvia.</p>\r\n<p>\r\n	Entre los cursos que se impartir&aacute;n est&aacute;n: introducci&oacute;n a la publicidad, t&eacute;cnicas publicitarias, mercadeo, producci&oacute;n gr&aacute;fica, estrategia creativa, comportamiento del consumidor, taller de creatividad publicitaria y redacci&oacute;n publicitaria.</p>\r\n<p>\r\n	La matr&iacute;cula para esta nueva carrera iniciar&aacute; el 14 de noviembre de este a&ntilde;o y las lecciones iniciar&aacute;n el 16 de enero del 2012. Para m&aacute;s informaci&oacute;n pueden ingresar al micro sitio de esta carrera, escribir a <a href="mailto:info@ucreativa.com">info@ucreativa.com</a> o llamar al 25-28-50-95.</p>\r\n<p>\r\n	&nbsp;\r\n<a href=''http://www.ucreativa.com/ucreasite/?s=carreras&idc=19'' title=''Creatividad Publicitaria'' target=''_self'' class=''link_careers''>Ver detalle de la Carrera</a>\r\n</p>\r\n\r\n', 'Ucreativa', 'Gabriela Calvo', 'A', '2011-10-27', '2011-10-27'),
(9, 'Era de Comunicación Digital', 'Era de Comunicación Digital', 'La Comunicación Digital ha adquirido un puesto muy importante en toda empresa, desde las multinacionales hasta las pequeñas empresas. La Universidad Creativa consiente de la necesidad ...', '<p>\r\n	La Comunicaci&oacute;n Digital ha adquirido un puesto muy importante en toda empresa, desde las multinacionales hasta las peque&ntilde;as empresas. La Universidad Creativa consiente de la necesidad que se ha generado en el campo profesional para ocupar puestos relacionados con esta &aacute;rea cre&oacute; una nueva carrera dentro de su oferta acad&eacute;mica.<br />\r\n	<br />\r\n	Se trata del Técnico Superior en Comunicaci&oacute;n Digital que abarca tres grandes &aacute;reas la teor&iacute;a, los talleres y el emprendimiento, que le brindar&aacute;n al graduado la posibilidad de adaptarse al &aacute;rea de medios sociales, siendo Comunnity Manager en agencias de publicidad, de relaciones p&uacute;blicas, de medios de comunicaci&oacute;n o departamentos de comunicaci&oacute;n y mercadeo.<br />\r\n	<br />\r\n	Toda persona que disfrute del trabajo en Internet y la navegaci&oacute;n por las redes sociales podr&aacute; optar por una carrera corta como este t&eacute;cnico superior en Comunicaci&oacute;n Digital, que dura tan solo 4 cuatrimestres para lograr insertarse en este prometedor campo laboral.<br />\r\n	<br />\r\n	Los egresados de esta carrera tambi&eacute;n podr&aacute;n desempe&ntilde;arse como administradores de su propio negocio y darle una promoci&oacute;n adecuada mediante las nuevas opciones que ofrece el mercado digital.<br />\r\n	<br />\r\n	Mauricio Fallas, director de la Unidad Digital de Unimer y qui&eacute;n se desempe&ntilde;o como director creativo de Garnier por algunos a&ntilde;os, ser&aacute; el director de &eacute;sta nueva carrera, que se ofertar&aacute; a partir del I Cuatrimestre del 2012.<br />\r\n	<br />\r\n	&Eacute;l confiesa que la aceptaci&oacute;n ha sido muy buena y que vislumbra muchos &eacute;xitos para la carrera. Mauricio explica que es probable que las primeras personas en matricular sean profesionales graduados que desean actualizarse en el tema digital, por ejemplo los relacionistas p&uacute;blicos, los periodistas, publicistas o programadores.<br />\r\n	<br />\r\n	Para m&aacute;s informaci&oacute;n pueden ingresar al micro sitio de esta carrera, escribir a <strong>info@ucreativa.com</strong> o llamar al <strong>25-28-50-95</strong>.\r\n<br /><br />\r\n<a href=''http://www.ucreativa.com/ucreasite/?s=carreras&idc=20'' title=''Comunicación Digital'' target=''_self'' class=''link_careers''>Ver detalle de la Carrera</a>\r\n</p>', 'Ucreativa', 'Gabriela Calvo A.', 'A', '2011-10-31', '2011-10-31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_sections`
--

CREATE TABLE IF NOT EXISTS `tbl_sections` (
  `section_id` int(11) NOT NULL auto_increment,
  `section_key` varchar(16) NOT NULL,
  `section_name` varchar(32) NOT NULL,
  `section_title` varchar(64) NOT NULL,
  `section_subtitle` varchar(64) default NULL,
  `section_description` varchar(1024) NOT NULL,
  `section_text` text NOT NULL,
  `section_showflag` varchar(1) NOT NULL default '0',
  `section_urlblog` varchar(128) default NULL,
  `section_keywords` varchar(128) NOT NULL,
  `section_status` varchar(1) NOT NULL default 'A',
  `section_created` date NOT NULL,
  `section_modified` date NOT NULL,
  PRIMARY KEY  (`section_id`),
  UNIQUE KEY `section_key` (`section_key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Volcar la base de datos para la tabla `tbl_sections`
--

INSERT INTO `tbl_sections` (`section_id`, `section_key`, `section_name`, `section_title`, `section_subtitle`, `section_description`, `section_text`, `section_showflag`, `section_urlblog`, `section_keywords`, `section_status`, `section_created`, `section_modified`) VALUES
(1, 'inicio', 'Inicio', 'Universidad Creativa de Costa Rica', 'Bienvenidos a la Universidad Creativa', 'Sitio Web de la Universidad Creativa', 'Una de cada 290 personas son creativas, esas son las que visitan este site.', '0', NULL, 'ucreativa, web, sabanilla', 'A', '2011-07-18', '2011-07-21'),
(2, 'quienes_somos', 'Quiénes Somos', 'Quiénes Somos', 'Quiénes Somos', 'Queremos que la Ucreativa sea tu casa.<br/><br/>\r\n\r\nPor eso creamos 15 carreras diseñadas para estimular lo creativo que llevás dentro y así podás ser un profesional que deje huella en cada proyecto que ejecute.', '[[Queremos que la Ucreativa sea tu casa]]\r\n<p>\r\nPor eso creamos 15 carreras diseñadas para estimular lo creativo que llevás dentro y así podás ser un profesional que deje huella en cada proyecto que ejecute.\r\n</p>\r\n[[Eureka!]]\r\n<p>\r\nEstamos convencidos que los estudiantes que llegan a la Ucreativa son víctimas de un sistema educativo estructurado que muchas veces (por no decir todas) trunca sus ambiciones profesionales. Por eso, el 16 de octubre de 1993 a las 9:23 am, mientras tomaba un café, la periodista y psicoanalista Master María Madrigal Monge tuvo la idea de crear un concepto diferente en educación superior.\r\n</p> [[', '0', NULL, 'ucreativa, web, sabanilla', 'A', '2011-07-18', '2011-07-18'),
(3, 'convenios', 'Convenios', 'Convenios', 'Convenios', 'Entra y conoce los convenios que posee la Universidad Creativa', '[[Creativos con influencias]]\r\n<b>CONVENIOS INSTITUCIONALES</b><br /><br />\r\n<p>\r\nEn aras de ofrecer mayores oportunidades y beneficios a nuestros estudiantes, la Universidad ha firmado una serie de convenios, en donde al ser agremiado o  familiar en primer grado de consanguineidad de éste puede hacerse acreedor de hasta un 25% de descuento.<br/><br/>\r\n<b>Instituciones</b>\r\n<br/<br/>\r\n<b>ANDE</b> (Asociación Nacional de Educadores de Costa Rica) <br/>\r\n<b>ASECCSS</b> (Asociación Solidarista de Empleados de la Caja Costarricense de Seguro Social) <br/>\r\n<b>ASEFYL</b> (Asociación de Empleados de Fuerza y Luz) <br/>\r\n<b>ASOBANCOSTA</b> (Asociación Solidarista del Banco de Costa Rica) <br/>\r\n<b>ASSEC</b> (Asociación Solidarista de Empleados de Credomatic) <br/>\r\n<b>ASTRACSA</b> (Asociación de Trabajadores de RACSA) <br/>\r\n<b>COLPER</b> (Colegio de Periodistas) <br/>\r\n<b>SAMTEC</b> <br/>\r\n<b>SINDHAC</b> (Ministerio de Hacienda) <br/>\r\n<b>ASEHOSPIRA</b> <br/>\r\n<b>GP Services Intermedia S.A.</b> <br/>\r\n<b>ASEDP</b> (Asociación Solidarista de Empleados de Dos Pinos) <br/>\r\n<b>ASEBAYER</b> (Asociación Solidarista de Empleados de Bayer) <br/>\r\n<b>CANATUR</b> (Cámara Nacional de Turismo) <br/>\r\n<b>ASENACSA</b> (Asociación Solidarista de Empleados de La Nación) <br/>\r\n<b>ASOMEGA</b> (Asociación Solidarista de Empleados de Corporación Megasuper S.A.) <br/>\r\n<b>ASADEM</b> (Asoc. Solidarista de Empleados de Corporación de Supermercados Unidos S.A.) <br/>\r\n<br/>\r\n</p>\r\n		     <b>Tabla de Descuentos</b><br /><br />\r\n<table>\r\n   <tr><td>GRADO ACADÉMICO</td><td>DESCUENTO</td></tr>\r\n   <tr><td>Licenciatura</td><td>25%</td></tr>\r\n   <tr><td>Bachillerato</td><td>15%</td></tr>\r\n   <tr><td>Diplomado</td><td>15%</td></tr>\r\n   <tr><td>Técnico Superior</td><td>15%</td></tr>\r\n   <tr><td>Cursos Libres, Taller y Laboratorio</td><td>20%</td></tr>\r\n</table>\r\n<br /><br />\r\n<b>Más convenios Institucionales</b><br /><br />\r\n<p>\r\n<b>Sursum</b>(Movimiento Solidarista Costarricense)\r\n                  <br/>\r\n	              <br/>\r\nCon más de 1000 asociaciones incorporadas beneficiadas\r\nPara ver más información del convenio establecido en:\r\n<a target="_blank" href="http://www.solidarismo.or.cr/Convenios-66/34"> http://www.solidarismo.or.cr/Convenios-66/34</a><br/><br/>\r\n<table>\r\n<tr><td>GRADO ACADÉMICO</td><td>DESCUENTO</td></tr>\r\n<tr><td>Licenciatura</td><td>5%</td></tr>\r\n<tr><td>Bachillerato</td><td>5%</td></tr>\r\n<tr><td>Diplomado</td><td>5%</td></tr>\r\n<tr><td>Técnico Superior</td><td>5%</td></tr>\r\n<tr><td>Cursos Libres, Taller y Laboratorio</td><td>5%</td></tr>\r\n</table><br/>\r\n</p>\r\n\r\n[[BENEFICIOS ESTUDIANTILES]]\r\n<b>¡Tener el carné de la U sí tiene beneficios!</b>\r\n<br/>\r\nAl presentar el carné de la U usted puede obtener descuentos en:<br/>\r\n<b>Laboratorios de San José</b> 30% de descuento<br/>\r\n<table>\r\n<tr><td>VENTAJAS ADICIONALES</td></tr>\r\n<tr><td>Análisis de agua y de alimentos</td></tr>\r\n<tr><td>Exámenes para la Manipulación de alimentos</td></tr>\r\n<tr><td>Prueba para la detección de VPH (Virus Papiloma Humano)</td></tr>\r\n</table><br/><br/>\r\n\r\n<p>\r\nPara poder aplicar el descuento basta con ser estudiante, administrativo o familiar en 2do grado de cualquiera de los dos casos.\r\n<br/>\r\n<b>Jiménez & Tanzi</b> 5% de descuento <br/>\r\n<b>Jbp/Reyma</b> existen descuentos desde 10% hasta 35%, dependiendo del trabajo solicitado.<br/>\r\n\r\n<b>Sony</b> descuentos variables.\r\n<br/>\r\n<b>Almacén Los Ángeles</b> descuentos para comprar máquinas de coser.\r\n<br/>\r\n</p>\r\n\r\n[[CONVENIOS ACADÉMICOS]]\r\n<b>Convenios Nacionales</b><br/><br/>\r\n\r\n<b>Clandestina Hub Creativo</b><br/><br/>\r\n<p>Clandestina convoca a líderes emprendedores en distintas áreas para crear nuevos cursos enfocados en contribuir decididamente al desarrollo creativo e innovador de Costa Rica. A la vez, desarrollaron un novedoso concepto de aprendizaje que se adapta a la sociedad tan cambiante en la que vivimos. Hoy es un HUB CREATIVO; es decir, un punto de conexión entre el pensamiento y el talento innovador para viajar a otras áreas de la sociedad.<br/><br/>\r\nEntre los beneficios del convenio están:<br/><br/>\r\n<ul>\r\n<li>Ofrecer descuentos tanto a estudiantes de la Universidad en Clandestina, como a estudiantes de Clandestina en la Universidad.</li>\r\n<li>Generar una retroalimentación en el área docente.</li>\r\n<li>Desarrollar proyectos innovadores en conjunto.</li>\r\n<li>Ofrecer Seminarios para todas las carreras</li></ul></p>\r\n<b>Universidad para la Cooperación Internacional</b><br/>\r\n\r\n<p>La Universidad para la Cooperación Internacional -UCI- es una Universidad Privada debidamente acreditada en Costa Rica por el Consejo Superior de Educación de las Universidades Privadas. Esta  surge como respuesta a la necesidad de contar con profesionales con una formación inter y multidisciplinaria, poseedores de los conocimientos, herramientas y valores para liderar los procesos de cambio requeridos, bajo los conceptos de sostenibilidad y globalización.</p><br/>\r\n\r\n<p>Entre los beneficios del convenio están:\r\n\r\n<br/>\r\n<ul>\r\n\r\n<li>Cooperación en nuestro programa de educación virtual</li>\r\n\r\n<li>Acreditación de maestrías especiales y que administraríamos conjuntamente.</li>\r\n\r\n<li>Intercambio de becas para la formación docente.</li>\r\n</ul></p>\r\n<br/>\r\n\r\n\r\n[[Creativos alrededor del mundo]]\r\n\r\n<p><b>Convenios internacionales</b><br/><br/></p>\r\n\r\n<p><b>FD Moda</b><br/><br/>\r\n<p>Reconocida por el Ministerio de Educación de Cataluña, es la escuela con mayor proyección en el área técnica de la moda: modelado, patronaje y confección. Está vinculada directamente con la pasarela 080 Barcelona.  \r\nOpciones que ofrece:<br/><br/>\r\n<ul>\r\n<li>Grado en Diseño de Moda</li>\r\n<li>Máster</li>\r\n<li>Postgrados</li>\r\n<li>Cursos Especialización</li>\r\n<li>Cursos On Line</li>\r\n<li>Práctica en reconocidas empresas de moda</li></ul><br/><br/></p>\r\n\r\n<p><b>Universidad Nacional del Nordeste - Argentina</b><br/><br/>\r\nLa Universidad Nacional del Nordeste, comunidad espiritual de docentes, alumnos, graduados y no docentes, procura la formación integral y armónica de sus componentes, y realiza en el seno de la sociedad una labor organizada y permanente, para propender a la dignificación integral del hombre, a la formación de una conciencia democrática, vigorosa y esclarecida y a la capacitación cultural y técnica de sus componentes y del pueblo del que forma parte, como órgano e instrumento de mejoramiento social al servicio de la nación y de los ideales de la humanidad. (Estatuto de la Universidad Nacional del Nordeste).<br/><br/>\r\nEntre los beneficios del convenio están:<br/><br/>\r\n<ul>\r\n<li>Movilidad estudiantil</li>\r\n<li>Reconocimiento de créditos</li></ul><br/><br/></p>\r\n\r\n<p><b>Universidad Autónoma de México</b><br/><br/>\r\nCon el nombre de la Real y Pontificia Universidad de México. Es la más grande e importante universidad de México e Iberoamérica. Tiene como propósito primordial estar al servicio del país y de la humanidad, formar profesionistas útiles a la sociedad, organizar y realizar investigaciones, principalmente acerca de las condiciones y problemas nacionales, y extender con la mayor amplitud posible, los beneficios de la cultura.<br/><br/>\r\nEntre los beneficios del convenio están:<br/><br/>\r\n<ul>\r\n<li>Movilidad estudiantil</li>\r\n<li>Reconocimiento de créditos</li></ul>\r\n</p>\r\n\r\n[[', '0', NULL, 'ucreativa,sabanilla', 'A', '2011-07-26', '2011-07-26'),
(4, 'noticias', 'Noticias', 'Noticias', 'Noticias', 'Noticias de la Ucreativa Creativa', 'Estrenamos site!!! Desarrollado por nuestro departamento in-house. Conocé al equipo creador del proyecto.', '0', NULL, 'ucreativa,noticias', 'A', '2011-07-23', '2011-07-01'),
(5, 'edificios', 'Edificios', 'Edificios', 'Direcciones:', '<b>Edificio de Sabanilla</b><br/>\n<i>Dirección:</i>&nbsp;\nSan José, Montes de Oca, Mercedes, de la Farmacia la Paulina 100 Este, 100 Norte y 250 Este. Residencial Guaymi, Calle B, lote 19\n<br/><br/>\n<b>Edificio de San Pedro</b><br/>\n<i>Dirección:</i>&nbsp;\nDel Outlet Mall 800 sur 200 oeste y 50 norte. Edificio color blanco esquinero, diagonal al edificio de la Cámara de Industrias.\n<br/><br/>\n<b>Edificio de Zapote</b><br/>\n<i>Dirección:</i>&nbsp;\nDel Outlet Mall San Pedro de Montes de Oca, 800 sur, 200 oeste, 50 sur.', '[[Edificio San Pedro]]\r\n<b>Dirección:</b>Del Outlet Mall 800 sur 200 oeste y 50 norte. Edificio color blanco esquinero, diagonal al edificio de la Cámara de Industrias.</br></br> \r\n<b>Servicios:</b>\r\n<br>1. Matrícula y Admisión.\r\n<br>2. Vida Universitaria.\r\n<br>3. Tesorería y Contabilidad.\r\n<br>4. Gerencia General.\r\n<br>5. Creatipos.\r\n\r\n[[Edificio Zapote]]\r\n<b>Dirección:</b> \r\nDel Outlet Mall San Pedro de Montes de Oca, 800 sur, 200 oeste, 50 sur.</br></br>\r\n<b>Servicios:</b>\r\n<br>1. Coordinación Académica.\r\n<br>2. Dirección de carreras.\r\n<br>3. Coordinación de Cátedras.\r\n<br>4. Centro de Impresión.\r\n\r\n[[Edificio Sabanilla]]\r\n<b>Dirección:</b>\r\nSan José, Montes de Oca, Mercedes, de la Farmacia la Paulina 100 Este, 100 Norte y 250 Este. Residencial Guaymi, Calle B, lote 19<br/></br>\r\n<b>Servicios:</b>\r\n<br>1. Registro.\r\n<br>2. Centro de Documentación "Priscilla Echeverría".\r\n<br>3. Mercadeo.\r\n<br>4. Tecnologías de Información Universitaria.\r\n\r\n[[', '0', '', 'Ucreativa,Edificios', 'A', '2011-08-03', '2011-08-03'),
(6, 'vida_u', 'VidaU', 'Vida U', 'Vida U', 'La Universidad Creativa alberga como ideal el que su enseñanza trascienda las fronteras del aprendizaje y fomente el crecimiento integral de su estudiantado. Vida Universitaria es una posibilidad real donde puedes disfrutar de servicios para satisfacer muchas áreas indispensables para tu formación personal y profesional.', '[[Pónganse cómodos en el diván (S.A.P: Servicio de Atención Psicológica)]]\r\n<p>\r\nEl departamento de Vida Universitaria, en busca de ofrecer brindarle a nuestra comunidad universitaria los servicios que les permitan obtener el mayor provecho de su estadía como miembros de nuestra casa de enseñanza, diseñó un sistema que les permite, si así lo desean, recibir acompañamiento psicológico subvencionado.<br/><br/>\r\nLa responsabilidad que tenemos como universidad va más allá del simple hecho de formar diseñadores de alta calidad. Pretendemos también que nuestros futuros profesionales cuenten con las herramientas psicológicas necesarias para llevar a cabo su praxis profesional con ética, responsabilidad y compromiso.<br/><br/> \r\nEl Servicio de Atención Psicológica se ofrece a todos los miembros de nuestra institución: alumnado, profesorado y parte administrativa.<br/><br/> \r\nHe aquí las condiciones para hacer uso de este beneficio: todo miembro de nuestra comunidad universitaria puede solicitar una entrevista inicial.<br/><br/> \r\nEn esa primera entrevista, la cual se llevará a cabo con el director del departamento, se aclararán todas las posibles dudas y posteriormente, en esa misma reunión, se elegirá cuál de los psicólogos de nuestra universidad se encargará del caso (contamos con un equipo de 3 profesionales en psicología). Esta primera entrevista no tiene costo. El interesado cuenta en ese momento con la información necesaria para iniciar su proceso con el psicólogo elegido.<br/><br/>  \r\nLuego de ésto, el terapeuta designado iniciará el proceso de atención psicológica, el cual podrá extenderse hasta alcanzar 10 sesiones. Estas sesiones se llevarán a cabo, ya sea en nuestras instalaciones o en los consultorios de cada uno de nuestros psicólogos.<br/><br/> \r\nEl monto a pagar por cada sesión será, por todo el año 2011, de c10.000 (diez mil colones). Si el estudiante conviniera continuar con su proceso terapéutico, luego de estas 10 sesiones, deberá establecer con su terapeuta un nuevo encuadre para su proceso. Debe aclararse que no necesariamente se deberán utilizar las 10 sesiones (eso dependerá de la solución de las metas terapéuticas).<br/><br/> \r\nEs importante aclarar que cada estudiante de nuestra universidad puede hacer uso de este sistema únicamente una vez a lo largo de su carrera y podrá hacerlo en cualquier momento de la misma.<br/><br/> \r\nPara recibir mayor información pueden comunicarse con la extensión 1103 ó escribir a <a href="mailto:allanfernandez@ucreativa.com">allanfernandez@ucreativa.com</a>\r\n</p>\r\n\r\n[["El arte nunca duerme" Gian Carlo Coppola (Servicio 24 horas)]]\r\n<p>\r\nSabemos que es probable que las mejores de sus ideas ocurran en la noche y por esta razón se ofrece el servicio de 24 horas en el edificio de Zapote. El servicio tiene como objetivo extender el tiempo de acceso para el uso de nuestros recursos y así lograr que todos nuestros estudiantes puedan desarrollar las distintas tareas y realizar horas prácticas según su necesidad. Esto se establece en una jornada de servicio nocturna de lunes a jueves 10:00 p.m. a 7:30 a.m. habilitando los siguientes espacios en el edificio de Zapote: \r\n<br/><br/>\r\n<ol>\r\n<li><b>Laboratorio MAC:</b> Acceso al uso de los equipos y software de diseño.</li>\r\n<li><b>Taller de Confección:</b> Una de las más importantes facilidades para nuestros estudiantes regulares se concentra en el Taller de Confección, equipado con alrededor 14 máquinas manuales, 4 planchas, maniquíes para modelación, entre otras muchas herramientas indispensables del área.</li>\r\n<li><b>Talleres o Aulas Habilitadas:</b> Acceso al uso de sillas, mesas, equipo de proyección.</li>\r\n<li><b>Estudio Fotográfico</b></li>\r\n</ol>\r\n<br/><br/>\r\nRequisitos para el uso del servicio Presentar el carné de estudiante o administrativo al encargado de supervisión de dicha jornada.\r\n</p> \r\n\r\n[[Perpetuá tus ideas]]\r\n<p>\r\nCon el fin de facilitar la presentación de sus tareas y proyectos la Universidad lleva a Over Print CR al edificio de Zapote. Este centro de impresión ofrece un servicio de lunes a viernes de <b>8:00 a.m. a 8:00 p.m.</b> \r\n<br/><br/>\r\n<b>Contacto: Edgar Garita Ulloa</b>\r\n<b>Teléfonos: 2283-5849 o 87217266</b> \r\n</p>\r\n\r\n[[La energía que hay en tí]]\r\n<p>\r\nLLa buena alimentación es fundamental para el rendimiento del ser humano. Por esta razón la Universidad ha procurado traer hasta sus edificios el servicio de cafetería.  La diversidad de productos y la inclusión de almuerzos se encuentran en los menús de este servicio. \r\nEl horario de atención en el edificio de San Pedro es de 8 a.m. a 8 a p.m.y en el edificio de Sabanilla <b>La Fonda Comidas Criollas</b> tiene un horario de atención de <b>lunes a jueves</b> de 9 a.m. a 8 p.m. y viernes de 9 a.m. a 5 p.m. \r\n\r\n</b> \r\n</p>\r\n\r\n[[Sacá tu lado creativo]]\r\n<p>\r\nLos estudiantes activos de la Universidad Creativa podrán acceder al uso del Estudio Fotográfico ubicado en el edificio de Zapote como parte de nuestros servicios internos.\r\nEste servicio también se encuentra habilitado para todo aquel estudiante inactivo, graduado, profesores o personas externas de la institución.\r\n<br/><br/>\r\n$80 por hora, persona externa y estudiantes inactivos.\r\n$60 por hora, estudiantes graduados.\r\n$50 por hora, estudiantes activos y profesores.\r\n<br/><br/>\r\nRequisitos para el uso del servicio Coordinación previa con encargado de supervisión Oscar Quesada por vía correo electrónico. El correo es: <b>oscar.quesada@ucreativa.com</b>\r\n</p>\r\n\r\n[[Para que desarrollés tus ideas]]\r\n<p>\r\nLos estudiantes de la Universidad Creativa podrán acceder al uso de nuestros laboratorios en sus distintas plataformas; parte del servicio permitirá acceder a mayores facilidades como el libre acceso a software de Diseño como Adobe Master Collection, Sketchup, Autodesk.\r\nPara reservar deben escribir a <b>http://reservaciones.ucreativa.com</b>\r\n</p>\r\n\r\n[[Creativos On line ]]\r\n<p>\r\nEl campus virtual consiste en un apoyo académico a los cursos presenciales. En un futuro llegará a ser parte de la oferta académica virtual.\r\n</p>\r\n\r\n[[Solo para apasionados de la moda ]]\r\n<p>\r\nEl taller de confección cuenta con horario de 24 horas de servicio para el estudiante que desee realizar sus proyectos en la Universidad. Éste está equipado con:<br/><br/>\r\nManiquíes profesionales para la confección<br/>\r\nPlanchas de uso industrial<br/>\r\nMejores accesorios para las máquinas de coser<br/>\r\nMesas de corte y confección especiales\r\nTambién se está gestionando la compra de máquinas industriales planas y overlock como complemento del taller de confección y patrones.\r\nPara reservar deben escribir a <b>http://reservaciones.ucreativa.com</b>\r\n</p>\r\n\r\n[[Una joya en bruto]]\r\n<p>Este taller de joyería y materiales fue generado a partir de la creación de la carrera de Diseño de Joyería y Accesorios. Parte del equipo que contiene es:<br/><br/>\r\nMesas de orfebrería<br/>\r\nMesas planas para trabajo<br/>\r\nSopletes<br/>\r\nHorno artesanal<br/>\r\nEsmerilador<br/>\r\nHerramientas de orfebrería y forja<br/>\r\nMesa de luz para toma de producto\r\n\r\n[[“Para viajar lejos no hay mejor nave que un libro” Emily Dickinson (Centro de documentación Priscilla Echeverría) ]]\r\n\r\nLa <b>biblioteca de la Universidad</b> tiene un horario de atención de lunes a viernes de 8 a.m. a 12:00 m.d. \r\n</br>y de 1:00 p.m. a 7 p.m. \r\n\r\n[[Conectados 24/7 (Wifi) ]]\r\n\r\nUno de los servicios más provechosos para todos los estudiantes es contar con Internet las 24 horas del día para satisfacer las necesidades académicas en cualquier edificio y momento. La contraseña es creativa.\r\n</p>\r\n[[Creatibus]] \r\n\r\n<p>A partir del III Cuatrimestre del 2011 inauguramos un nuevo servicio: el Transporte del edificio de Zapote a Sabanilla y viceversa, saliendo cada hora del edificio de Zapote a partir de las 5:05 p.m.  y hasta las 10:05 p.m. (este último rol llega hasta Chelles). <b>Importante:</b> al ser un servicio subsidiado es imprescindible presentar el carné de la Universidad y pagar el monto de 300 colones.\r\n</p>\r\n[[', '0', '', 'vida u, ucreativa', 'A', '2011-08-03', '2011-08-03'),
(7, 'vecinos', 'Vecinos', 'Vecinos', 'Enlaces Vecinos', 'La Universidad Creativa cuenta con muchos aliados, entra y entéreate de quienes se tratan!!', '', '0', '', '', 'A', '2011-08-03', '2011-08-03'),
(8, 'preguntas', 'Preguntas', 'Preguntas FAQ', 'Preguntas', '¿Sos obsesivo por la creatividad?:&nbsp;\r\nComo dijo Francis Ford Coppola "El arte nunca duerme". Sabemos que las mejores ideas nacen en la madrugada (u horas antes del tiempo de entrega del proyecto) por eso nuestros estudiantes cuentan con aulas para conceptualizar 24/7. ', '[[¿Cuáles son las fechas de matrículas?]]\r\n<p>\r\nLa matrícula se lleva a cabo en enero, mayo y en setiembre. Para saber fechas exactas deben estar pendientes de nuestras redes sociales o llamar al departamento de Servicio al Cliente al 25-28-50-95.\r\n</p>\r\n\r\n[[¿Cuáles son los horarios de los diferentes cursos?]]\r\n<p>\r\nLos horarios de los diferentes cursos pueden consultarlos en el departamento de Servicio al Cliente al 25-28-50-95 desde el momento que inicia la matrícula o pueden escribir al correo <b>info@ucreativa.com</b>\r\n<br/>\r\n<br/>\r\n<a href=''http://www.ucreativa.com/ucreasite/app_core/resources/files/sections/section_carreras/Horario_IIIC-2011MALLA.pdf'' target=''_blank'' title=''Horarios''>Descargar horarios</a>\r\n</p>\r\n\r\n[[¿Cuál es el costo de la carrera que deseo estudiar?]]\r\n<p>\r\nEl costo es diferente en cada carrera. Cada carrera tiene cursos que tienen costos diferentes y que pueden variar a lo largo del tiempo.\r\n</p>\r\n[[', '0', NULL, 'preguntas,faq,ucreativa', 'A', '2011-08-03', '2011-08-03'),
(9, 'inversion', 'Inversion', 'Inversión', 'Inversion', 'La Universidad Creativa en aras de ofrecer mejores oportunidades a sus estudiantes tiene diferentes opciones de financiamiento para todas las carreras.', '[[Invertí en tu talento]]\r\n\r\n<p>\r\nLas categorías están ligadas a la cantidad de tiempo por semana que el estudiante debe dedicarle al curso matriculado. El detalle a continuación:\r\n<ol>\r\n<li>Categoría A: 2 horas por semana</li>\r\n<li>Categoría B: 3 horas por semana</li>\r\n<li>Categoría C: 4 horas por semana</li>\r\n<li>Categoría D: 6 ó más horas por semana</li>\r\n</ol>\r\n<br/>\r\n\r\n<table>\r\n<tr><td>Carné</td><td>5,000.00</td></tr>\r\n<tr><td>Certificaciones Generales</td><td>15,000.00</td></tr>\r\n<tr><td>Certificación Conape</td><td>7,500.00</td></tr>\r\n<tr><td>Retiro de materias</td><td>9,000.00</td></tr>\r\n<tr><td>Programas de materias</td><td>6,000.00</td></tr>\r\n<tr><td>Convalidación interna</td><td>15,000.00</td></tr>\r\n<tr><td>Presentación de proyectos de graduación</td><td>30,000.00</td></tr>\r\n<tr><td>Cambio de materia</td><td>9,000.00</td></tr>\r\n<tr><td>Suficiencia</td><td>35,000.00</td></tr>\r\n<tr><td>Congelamiento</td><td>9,000.00</td></tr>\r\n<tr><td>Examen de ampliación</td><td>12,000.00</td></tr>\r\n<tr><td>Derecho uso auditorio para tesis privada</td><td>30,000.00</td></tr>\r\n<tr><td>Derecho uso auditorio tesis pública </td><td>30,000.00</td></tr>\r\n</table>\r\n\r\n<br/><br/>\r\n<b>Sí, es posible estudiar lo que deseas</b><br/><br/>\r\nLa Universidad Creativa tiene a disposición una serie de opciones de pago para que podas realizar tu sueño; ser un profesional en cuales quiera de las ramas del diseño.<br/><br/>\r\nEntre nuestros sistemas internos de pago se encuentran el pago cuatrimestral y el pago unicuota.\r\n<br/><br/>\r\n<b>Pago Cuatrimestral</b>\r\n<br/><br/>\r\nEste pago se realiza con una letra de cambio, que debe cancelar en 4 cuotas iguales a pagarse el último día de cada mes.\r\n<br/><br/>\r\n<b>Matrícula + Materias + 10% de interés=</b> Total</br>\r\n<b>Primer Cuota=</b> 25% de total, se cancela al efectuar la matrícula.</br>\r\n<b>Segunda Cuota=</b> 25% del total, se cancela el ultimo día del segundo mes.</br>\r\n<b>Tercera Cuota=</b> 25% del total, se cancela el ultimo día del tercer mes.</br>\r\n<b>Cuarta Cuota=</b> 25% del total, se cancela el ultimo día del cuarto mes.</br>\r\n<br/><br/>\r\n<b>Pago Unicuota</b>\r\nEl Crédito podrá ofrecerse por 36 meses o 48 meses con una tasa del 19.5% y 24.5 % respectivamente a solicitud del cliente, cobrando por adelantado la primera cuota, siendo el mismo respaldado por Letra de Cambio.\r\n<br/><br/> \r\n<b>Requisitos para opción de pago interna</b>\r\n<br/><br/>\r\nCaracterísticas laborales del fiador:\r\n<ul>\r\n<li>6 meses como mínimo de laborar en el empleo actual.</li>\r\n<li>1 año de cotizar para la C.C.S.S.</li>\r\n<li>Salario mínimo neto de 220.000.00 mensuales.</li>\r\n</ul>\r\n\r\nEl fiador deberá presentar los siguientes documentos (originales y copia):\r\n<br/><br/>\r\n<ul>\r\n<li>Cédula de identidad</li>\r\n<li>Orden Patronal al día</li>\r\n<li>Constancia Salarial con menos de 15 días de haber sido extendida.</li>\r\n<li>Recibo de Servicio Público</li>\r\n</ul>\r\nAdicionalmente contamos con opciones de pago con entidades ajenas a la Universidad, como es el caso de CONAPE y el Banco Nacional de Costa Rica.\r\n<br/><br/>\r\n\r\n[[¿Desea realizar la cancelación por depósito bancario o transferencia electrónica?]]\r\n<b>Banco BAC San José </b><br/><br/>\r\nColones: 900-176975<br/><br/>\r\n<b>Banco Nacional</b> <br/><br/>\r\nDólares: 100-02-173-000049-8<br/>\r\nColones: 100-01-173-000129-8<br/><br/>\r\nEn caso de realizar su matrícula vía teléfono, debe enviar el comprobante de pago a <b>pagosestudiantes@ucreativa.com</b>.<br/><br/>\r\n<b>Muy pronto contaremos con la opción de pago por Internet.</b>\r\n<br/><br/>\r\n<b>Requisitos de Admisión</b></br></br>\r\n\r\n<b>Diplomados, Bachilleratos y Licenciaturas</b>\r\n<ul>\r\n<li>Título de Bachillerato (Original y tres fotocopias)</li>\r\n<li>Cédula de identidad (Original y copia)</li>\r\n<li>Tres fotografías tamaño pasaporte</li>\r\n</ul>\r\n\r\n<b>Técnicos</b><br/>\r\nCédula de identidad (Copia)<br/>\r\nTres fotografías tamaño pasaporte<br/>[[', '0', NULL, 'inversion, ucreativa', 'A', '2011-08-03', '2011-08-03'),
(10, 'carreras', 'Carreras', 'Carreras', 'Carreras', 'La Universidad Creativa tiene 15 carreras especializadas en diseño y enfocadas en cuatro grandes áreas, el área gráfica, el área de moda, el área de arquitectura y el área de comunicación.', '', '0', '', '', 'A', '2011-08-03', '2011-08-03'),
(11, 'eventos', 'Eventos', 'Eventos', 'Eventos', '', '', '0', '', 'eventos,ucreativa', 'A', '2011-08-08', '2011-08-11'),
(12, 'calendario', 'Calendario', 'Calendario Institucional', 'Calendario Institucional', 'Calendario Institucional de la Universidad Creativa', '', '0', NULL, 'Calendario Institucional, ucreativa', 'A', '2011-10-31', '2011-10-31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tags`
--

CREATE TABLE IF NOT EXISTS `tbl_tags` (
  `tag_id` int(11) NOT NULL auto_increment,
  `tag_name` varchar(64) NOT NULL,
  `tag_status` varchar(1) NOT NULL default 'A',
  `tag_created` date NOT NULL,
  `tag_modified` date NOT NULL,
  PRIMARY KEY  (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_tags`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tags_careers`
--

CREATE TABLE IF NOT EXISTS `tbl_tags_careers` (
  `tag_career_id` int(11) NOT NULL auto_increment,
  `tag_fk` int(11) NOT NULL,
  `career_fk` int(11) NOT NULL,
  PRIMARY KEY  (`tag_career_id`),
  KEY `tag_fk` (`tag_fk`),
  KEY `career_fk` (`career_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_tags_careers`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tags_events`
--

CREATE TABLE IF NOT EXISTS `tbl_tags_events` (
  `tag_event_id` int(11) NOT NULL auto_increment,
  `tag_fk` int(11) NOT NULL,
  `event_fk` bigint(20) NOT NULL,
  PRIMARY KEY  (`tag_event_id`),
  KEY `tag_fk` (`tag_fk`),
  KEY `event_fk` (`event_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_tags_events`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tags_files`
--

CREATE TABLE IF NOT EXISTS `tbl_tags_files` (
  `tag_file_id` int(11) NOT NULL auto_increment,
  `tag_fk` int(11) NOT NULL,
  `file_fk` bigint(20) NOT NULL,
  PRIMARY KEY  (`tag_file_id`),
  KEY `tag_fk` (`tag_fk`),
  KEY `file_fk` (`file_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_tags_files`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tags_news`
--

CREATE TABLE IF NOT EXISTS `tbl_tags_news` (
  `tag_new_id` int(11) NOT NULL auto_increment,
  `tag_fk` int(11) NOT NULL,
  `new_fk` bigint(20) NOT NULL,
  PRIMARY KEY  (`tag_new_id`),
  KEY `tag_fk` (`tag_fk`),
  KEY `new_fk` (`new_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_tags_news`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tags_sections`
--

CREATE TABLE IF NOT EXISTS `tbl_tags_sections` (
  `tag_section_id` int(11) NOT NULL auto_increment,
  `tag_fk` int(11) NOT NULL,
  `section_fk` int(11) NOT NULL,
  PRIMARY KEY  (`tag_section_id`),
  KEY `tag_fk` (`tag_fk`),
  KEY `section_fk` (`section_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_tags_sections`
--


--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `tbl_careers`
--
ALTER TABLE `tbl_careers`
  ADD CONSTRAINT `tbl_careers_area_fk_fkey` FOREIGN KEY (`area_fk`) REFERENCES `tbl_areas` (`area_id`),
  ADD CONSTRAINT `tbl_careers_ibfk_1` FOREIGN KEY (`area_fk`) REFERENCES `tbl_areas` (`area_id`),
  ADD CONSTRAINT `tbl_careers_ibfk_2` FOREIGN KEY (`area_fk`) REFERENCES `tbl_areas` (`area_id`),
  ADD CONSTRAINT `tbl_careers_ibfk_3` FOREIGN KEY (`area_fk`) REFERENCES `tbl_areas` (`area_id`),
  ADD CONSTRAINT `tbl_careers_ibfk_4` FOREIGN KEY (`area_fk`) REFERENCES `tbl_areas` (`area_id`),
  ADD CONSTRAINT `tbl_careers_ibfk_5` FOREIGN KEY (`area_fk`) REFERENCES `tbl_areas` (`area_id`);

--
-- Filtros para la tabla `tbl_files_careers`
--
ALTER TABLE `tbl_files_careers`
  ADD CONSTRAINT `tbl_files_careers_ibfk_1` FOREIGN KEY (`file_fk`) REFERENCES `tbl_files` (`file_id`),
  ADD CONSTRAINT `tbl_files_careers_ibfk_2` FOREIGN KEY (`career_fk`) REFERENCES `tbl_careers` (`career_id`);

--
-- Filtros para la tabla `tbl_files_events`
--
ALTER TABLE `tbl_files_events`
  ADD CONSTRAINT `tbl_files_events_ibfk_1` FOREIGN KEY (`file_fk`) REFERENCES `tbl_files` (`file_id`),
  ADD CONSTRAINT `tbl_files_events_ibfk_2` FOREIGN KEY (`event_fk`) REFERENCES `tbl_events` (`event_id`);

--
-- Filtros para la tabla `tbl_files_news`
--
ALTER TABLE `tbl_files_news`
  ADD CONSTRAINT `tbl_files_news_ibfk_1` FOREIGN KEY (`file_fk`) REFERENCES `tbl_files` (`file_id`),
  ADD CONSTRAINT `tbl_files_news_ibfk_2` FOREIGN KEY (`new_fk`) REFERENCES `tbl_news` (`new_id`);

--
-- Filtros para la tabla `tbl_files_sections`
--
ALTER TABLE `tbl_files_sections`
  ADD CONSTRAINT `tbl_files_sections_ibfk_1` FOREIGN KEY (`file_fk`) REFERENCES `tbl_files` (`file_id`),
  ADD CONSTRAINT `tbl_files_sections_ibfk_2` FOREIGN KEY (`section_fk`) REFERENCES `tbl_sections` (`section_id`);

--
-- Filtros para la tabla `tbl_tags_careers`
--
ALTER TABLE `tbl_tags_careers`
  ADD CONSTRAINT `tbl_tags_careers_ibfk_1` FOREIGN KEY (`tag_fk`) REFERENCES `tbl_tags` (`tag_id`),
  ADD CONSTRAINT `tbl_tags_careers_ibfk_2` FOREIGN KEY (`career_fk`) REFERENCES `tbl_careers` (`career_id`);

--
-- Filtros para la tabla `tbl_tags_events`
--
ALTER TABLE `tbl_tags_events`
  ADD CONSTRAINT `tbl_tags_events_ibfk_2` FOREIGN KEY (`tag_fk`) REFERENCES `tbl_tags` (`tag_id`),
  ADD CONSTRAINT `tbl_tags_events_ibfk_3` FOREIGN KEY (`event_fk`) REFERENCES `tbl_events` (`event_id`);

--
-- Filtros para la tabla `tbl_tags_files`
--
ALTER TABLE `tbl_tags_files`
  ADD CONSTRAINT `tbl_tags_files_ibfk_1` FOREIGN KEY (`tag_fk`) REFERENCES `tbl_tags` (`tag_id`),
  ADD CONSTRAINT `tbl_tags_files_ibfk_2` FOREIGN KEY (`file_fk`) REFERENCES `tbl_files` (`file_id`);

--
-- Filtros para la tabla `tbl_tags_news`
--
ALTER TABLE `tbl_tags_news`
  ADD CONSTRAINT `tbl_tags_news_ibfk_1` FOREIGN KEY (`tag_fk`) REFERENCES `tbl_tags` (`tag_id`),
  ADD CONSTRAINT `tbl_tags_news_ibfk_2` FOREIGN KEY (`new_fk`) REFERENCES `tbl_news` (`new_id`);

--
-- Filtros para la tabla `tbl_tags_sections`
--
ALTER TABLE `tbl_tags_sections`
  ADD CONSTRAINT `tbl_tags_sections_ibfk_1` FOREIGN KEY (`tag_fk`) REFERENCES `tbl_tags` (`tag_id`),
  ADD CONSTRAINT `tbl_tags_sections_ibfk_2` FOREIGN KEY (`section_fk`) REFERENCES `tbl_sections` (`section_id`);
